"""
OmniFi — Deauth Attack Detector  (fixed: no capture_seconds param on run())
"""
import time, collections
from dataclasses import dataclass

try:
    from scapy.all import sniff, Dot11, Dot11Deauth, Dot11Disas
    SCAPY_AVAILABLE = True
except ImportError:
    SCAPY_AVAILABLE = False

CAPTURE_SECONDS     = 30
DEAUTH_BURST_THRESH = 10
FRAME_WINDOW_SEC    = 2.0
DEAUTH_SUBTYPE      = 12
DISASSOC_SUBTYPE    = 10


@dataclass
class DeauthEvent:
    src_mac: str; dst_mac: str; frame_type: str
    reason_code: int; timestamp: float


class DeauthDetector:
    def __init__(self, interface="wlan0mon", verbose=True,
                 capture_seconds: int = CAPTURE_SECONDS):
        self.interface    = interface
        self.verbose      = verbose
        self._cap_sec     = capture_seconds
        self.events: list = []
        self.rate_window: dict = collections.defaultdict(list)
        self.alerts: list = []
        self._alerted: set = set()

    def run(self) -> dict:
        """Run deauth detection. capture_seconds is set at __init__ time."""
        if not SCAPY_AVAILABLE:
            self._print("[!] Scapy not installed — pip install scapy")
            return {"alerts": [], "attack_detected": False,
                    "error": "Scapy not available"}
        self._print(f"[OmniFi] Deauth Detector — sniffing {self._cap_sec}s on {self.interface}...")
        try:
            sniff(iface=self.interface, prn=self._handle_packet,
                  timeout=self._cap_sec, store=False, monitor=True)
        except Exception as e:
            self._print(f"[!] Sniff error: {e}")
            return {"alerts": self.alerts, "attack_detected": False,
                    "error": str(e)}
        return self._analyse()

    def _handle_packet(self, pkt):
        if not pkt.haslayer(Dot11): return
        dot11 = pkt[Dot11]
        if dot11.type != 0: return
        subtype = dot11.subtype
        if subtype == DEAUTH_SUBTYPE:
            frame_type = "deauth"
            reason_code = getattr(pkt.getlayer(Dot11Deauth), 'reason', 0)
        elif subtype == DISASSOC_SUBTYPE:
            frame_type = "disassoc"
            reason_code = getattr(pkt.getlayer(Dot11Disas), 'reason', 0)
        else:
            return
        src_mac = dot11.addr2 or "unknown"
        dst_mac = dot11.addr1 or "unknown"
        now     = time.time()
        self.events.append(DeauthEvent(src_mac, dst_mac, frame_type, reason_code, now))
        self.rate_window[src_mac].append(now)
        self.rate_window[src_mac] = [t for t in self.rate_window[src_mac]
                                      if now - t <= FRAME_WINDOW_SEC]
        rate = len(self.rate_window[src_mac]) / FRAME_WINDOW_SEC
        if rate >= DEAUTH_BURST_THRESH and src_mac not in self._alerted:
            self._alerted.add(src_mac)
            msg = (f"DEAUTH ATTACK from {src_mac} — {rate:.0f} frames/sec. "
                   f"Wi-Fi connection is being disrupted. Evil twin likely active.")
            self.alerts.append({"level": "critical", "message": msg,
                                 "detail": f"Target: {dst_mac}"})
            self._print(f"[!!!] {msg}")

    def _analyse(self) -> dict:
        return {
            "attack_detected":  len(self._alerted) > 0,
            "attacker_macs":    list(self._alerted),
            "total_deauth":     sum(1 for e in self.events if e.frame_type == "deauth"),
            "total_disassoc":   sum(1 for e in self.events if e.frame_type == "disassoc"),
            "total_frames":     len(self.events),
            "alerts":           self.alerts,
        }

    def _print(self, msg):
        if self.verbose: print(msg)
