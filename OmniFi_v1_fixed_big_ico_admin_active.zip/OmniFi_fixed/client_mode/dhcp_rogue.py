"""
OmniFi — DHCP Rogue Server Detector (fixed: capture_seconds at __init__)
"""
import time
from collections import defaultdict

try:
    from scapy.all import sniff, DHCP, BOOTP, Ether, IP
    SCAPY_AVAILABLE = True
except ImportError:
    SCAPY_AVAILABLE = False

_DEFAULT_CAP_SEC = 30


class RogueDHCPDetector:
    def __init__(self, interface="wlan0", verbose=True,
                 capture_seconds: int = _DEFAULT_CAP_SEC):
        self.interface    = interface
        self.verbose      = verbose
        self._cap_sec     = capture_seconds
        self.dhcp_servers: dict = {}
        self.alerts: list = []

    def run(self) -> dict:
        if not SCAPY_AVAILABLE:
            self._print("[!] Scapy not installed — pip install scapy")
            return {"alerts": [], "rogue_detected": False,
                    "error": "Scapy not available"}
        self._print(f"[OmniFi] DHCP Rogue Detector — sniffing {self._cap_sec}s...")
        try:
            sniff(iface=self.interface,
                  filter="udp and (port 67 or port 68)",
                  prn=self._handle_packet,
                  timeout=self._cap_sec, store=False)
        except Exception as e:
            self._print(f"[!] Sniff error: {e}")
            return {"alerts": self.alerts, "rogue_detected": False,
                    "error": str(e)}
        return self._analyse()

    def _handle_packet(self, pkt):
        if not (pkt.haslayer(DHCP) and pkt.haslayer(BOOTP)): return
        options = {opt[0]: opt[1] for opt in pkt[DHCP].options
                   if isinstance(opt, (list, tuple)) and len(opt) >= 2}
        msg_type = options.get("message-type", 0)
        if msg_type != 2:  # DHCP OFFER only
            return
        server_ip = pkt[IP].src if pkt.haslayer(IP) else pkt[BOOTP].siaddr
        mac       = pkt[Ether].src if pkt.haslayer(Ether) else "unknown"
        if server_ip not in self.dhcp_servers:
            self.dhcp_servers[server_ip] = []
        self.dhcp_servers[server_ip].append({"mac": mac, "ts": time.time()})
        self._print(f"  [DHCP OFFER] from {server_ip} (MAC {mac})")

    def _analyse(self) -> dict:
        rogue = len(self.dhcp_servers) > 1
        if rogue:
            ips = list(self.dhcp_servers.keys())
            msg = (f"ROGUE DHCP SERVER detected! "
                   f"{len(ips)} DHCP servers present: {', '.join(ips)}. "
                   f"All traffic may be redirected through attacker gateway.")
            self.alerts.append({"level": "critical", "message": msg,
                                 "detail": str(self.dhcp_servers)})
            self._print(f"[!!!] {msg}")
        elif len(self.dhcp_servers) == 1:
            ip = list(self.dhcp_servers.keys())[0]
            self._print(f"  [+] Single DHCP server {ip} — normal.")
        else:
            self._print("  [i] No DHCP OFFER seen in capture window.")
        return {
            "rogue_detected": rogue,
            "dhcp_servers":   self.dhcp_servers,
            "alerts":         self.alerts,
        }

    def _print(self, msg):
        if self.verbose: print(msg)
