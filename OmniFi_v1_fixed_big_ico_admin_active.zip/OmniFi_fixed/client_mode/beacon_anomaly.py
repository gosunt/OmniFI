"""
OmniFi — Beacon Interval Anomaly Detector (fixed: capture_seconds at __init__)
"""
import time, statistics
from collections import defaultdict

try:
    from scapy.all import sniff, Dot11Beacon, Dot11, Dot11Elt
    SCAPY_AVAILABLE = True
except ImportError:
    SCAPY_AVAILABLE = False

STANDARD_INTERVAL_MS = 100
TOLERANCE_MS         = 30
MIN_BEACONS_TO_JUDGE = 10
_DEFAULT_CAP_SEC     = 20


class BeaconAnomalyDetector:
    def __init__(self, interface="wlan0mon", verbose=True,
                 capture_seconds: int = _DEFAULT_CAP_SEC):
        self.interface    = interface
        self.verbose      = verbose
        self._cap_sec     = capture_seconds
        self.beacon_times: dict = defaultdict(list)
        self.results      = []
        self.alerts: list = []

    def run(self) -> list:
        if not SCAPY_AVAILABLE:
            self._print("[!] Scapy not installed — pip install scapy")
            return []
        self._print(f"[OmniFi] Beacon Anomaly Detector — sniffing {self._cap_sec}s on {self.interface}...")
        try:
            sniff(iface=self.interface, prn=self._handle_packet,
                  timeout=self._cap_sec, store=False, monitor=True)
        except Exception as e:
            self._print(f"[!] Sniff error: {e}")
            self.alerts.append({"level": "warn", "message": f"Sniff error: {e}"})
            return self.results
        return self._analyse()

    def _handle_packet(self, pkt):
        if not (pkt.haslayer(Dot11Beacon) and pkt.haslayer(Dot11)):
            return
        bssid = pkt[Dot11].addr3 or pkt[Dot11].addr2 or "unknown"
        # Extract SSID
        ssid = ""
        if pkt.haslayer(Dot11Elt):
            try: ssid = pkt[Dot11Elt].info.decode(errors="replace")
            except Exception: ssid = "?"
        key = f"{bssid}|{ssid}"
        self.beacon_times[key].append(time.time())

    def _analyse(self) -> list:
        for key, times in self.beacon_times.items():
            if len(times) < MIN_BEACONS_TO_JUDGE:
                continue
            bssid, ssid = key.split("|", 1)
            intervals_ms = [(times[i+1]-times[i])*1000
                            for i in range(len(times)-1)]
            mean_ms = statistics.mean(intervals_ms)
            stdev   = statistics.stdev(intervals_ms) if len(intervals_ms) > 1 else 0
            deviation = abs(mean_ms - STANDARD_INTERVAL_MS)
            status = "normal" if deviation <= TOLERANCE_MS else "anomalous"
            r = {"bssid": bssid, "ssid": ssid, "mean_ms": round(mean_ms,1),
                 "stdev_ms": round(stdev,1), "deviation_ms": round(deviation,1),
                 "beacon_count": len(times), "status": status}
            self.results.append(r)
            if status == "anomalous":
                msg = (f"Beacon anomaly on {ssid or bssid}: mean interval "
                       f"{mean_ms:.0f}ms (expected ~{STANDARD_INTERVAL_MS}ms). "
                       f"Possible rogue AP or hostapd-wpe.")
                self.alerts.append({"level": "high", "message": msg,
                                    "detail": str(r)})
                self._print(f"  [!] {msg}")
        return self.results

    def _print(self, msg):
        if self.verbose: print(msg)
