"""
OmniFi — Session Hijacking Detector (fixed: capture_seconds at __init__)
Checks HTTPS enforcement, passive cleartext credential sniff, cookie flags.
"""
import re

try:
    from scapy.all import sniff, TCP, Raw, IP
    SCAPY_AVAILABLE = True
except ImportError:
    SCAPY_AVAILABLE = False

try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False

CREDENTIAL_PATTERNS = [
    r"(?:username|user|email|login|userid)\s*=\s*[^&\s]{3,}",
    r"(?:password|passwd|pwd|pass)\s*=\s*[^&\s]{3,}",
]

HTTPS_EXPECTED_SITES = [
    "http://www.sbi.co.in", "http://www.hdfcbank.com",
    "http://www.icicibank.com", "http://www.axisbank.com",
    "http://www.gmail.com", "http://www.facebook.com",
    "http://www.instagram.com", "http://www.amazon.in",
]

_DEFAULT_CAP_SEC = 15


class SessionHijackDetector:
    def __init__(self, interface="wlan0", verbose=True,
                 capture_seconds: int = _DEFAULT_CAP_SEC):
        self.interface    = interface
        self.verbose      = verbose
        self._cap_sec     = capture_seconds
        self.alerts: list = []
        self._cred_seen   = False

    def run(self) -> dict:
        self._print("[OmniFi] Session Hijacking Detector...")
        results = {
            "cleartext_creds_observed": False,
            "insecure_cookie_sites":    [],
            "http_when_https_expected": [],
            "alerts":                   self.alerts,
        }
        results["http_when_https_expected"] = self._check_https_enforcement()
        if SCAPY_AVAILABLE:
            results["cleartext_creds_observed"] = self._sniff_for_cleartext_creds()
        else:
            self._print("[i] Scapy not available — skipping passive credential sniff.")
        return results

    def check_response_cookies(self, url: str) -> list:
        if not REQUESTS_AVAILABLE:
            return []
        issues = []
        try:
            r = requests.get(url, timeout=4, verify=True, allow_redirects=True)
            for cookie in r.cookies:
                if not cookie.secure:
                    issues.append(f"{url}: Cookie '{cookie.name}' missing Secure flag.")
                    self._alert(f"Cookie '{cookie.name}' on {url} missing Secure flag.", "medium")
                if not cookie.has_nonstandard_attr("HttpOnly"):
                    issues.append(f"{url}: Cookie '{cookie.name}' missing HttpOnly flag.")
        except Exception as e:
            self._print(f"  [!] Cookie check error for {url}: {e}")
        return issues

    def _check_https_enforcement(self) -> list:
        if not REQUESTS_AVAILABLE:
            return []
        violations = []
        for url in HTTPS_EXPECTED_SITES:
            try:
                r = requests.get(url, timeout=3, allow_redirects=False)
                if r.status_code == 200 and not url.startswith("https"):
                    msg = f"{url} served over HTTP without redirect — credentials exposed."
                    violations.append(url)
                    self._alert(msg, "high")
                    self._print(f"  [!] {msg}")
            except Exception:
                pass
        return violations

    def _sniff_for_cleartext_creds(self) -> bool:
        found = False
        compiled = [re.compile(p, re.IGNORECASE) for p in CREDENTIAL_PATTERNS]

        def handle(pkt):
            nonlocal found
            if not (pkt.haslayer(TCP) and pkt.haslayer(Raw)):
                return
            try:
                payload = pkt[Raw].load.decode("utf-8", errors="ignore")
            except Exception:
                return
            for pat in compiled:
                if pat.search(payload):
                    src = pkt[IP].src if pkt.haslayer(IP) else "?"
                    msg = (f"Cleartext credentials detected in HTTP traffic from {src}. "
                           f"Credentials may be visible to network observers.")
                    if msg not in [a["message"] for a in self.alerts]:
                        self._alert(msg, "critical")
                        self._print(f"  [!!!] {msg}")
                    found = True
                    break

        try:
            sniff(iface=self.interface, filter="tcp port 80",
                  prn=handle, timeout=self._cap_sec, store=False)
        except Exception as e:
            self._print(f"  [!] Sniff error: {e}")
        return found

    def _alert(self, msg, level="medium"):
        self.alerts.append({"level": level, "message": msg})

    def _print(self, msg):
        if self.verbose: print(msg)
