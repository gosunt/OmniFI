"""
OmniFi — Windows Npcap Auto-Installer
========================================
Checks whether Npcap is installed on Windows.
If not, offers to download and launch the installer automatically.

This module is called at startup (Windows only) from main.py
and from the Monitor Mode dialog when Npcap is not detected.
"""
from __future__ import annotations

import logging
import os
import platform
import subprocess
import sys
import tempfile
import threading
from typing import Callable, Optional

log = logging.getLogger("OmniFi.NpcapInstaller")

NPCAP_URL = "https://npcap.com/dist/npcap-1.82.exe"
NPCAP_SILENT_ARGS = [
    "/S",                     # silent install
    "/winpcap_mode=yes",      # WinPcap API-compatible mode
    "/loopback_support=yes",  # loopback capture
    "/dot11_support=yes",     # 802.11 raw frame support
    "/admin_only=no",         # allow non-admin to capture
]

WIN = platform.system() == "Windows"


# ─────────────────────────────────────────────────────────────────────────────
def is_npcap_installed() -> bool:
    """Return True if Npcap is installed (registry check + DLL check)."""
    if not WIN:
        return True   # On Linux/macOS, libpcap is handled differently
    # Registry check
    try:
        import winreg
        key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                             r"SOFTWARE\Npcap", 0, winreg.KEY_READ)
        winreg.CloseKey(key)
        return True
    except Exception:
        pass
    # DLL check
    for path in [
        r"C:\Windows\System32\Npcap\wpcap.dll",
        r"C:\Windows\SysWOW64\Npcap\wpcap.dll",
        r"C:\Windows\System32\wpcap.dll",
    ]:
        if os.path.exists(path):
            return True
    return False


def is_admin() -> bool:
    """Return True if the current process has admin / elevated privileges."""
    if not WIN:
        return os.geteuid() == 0
    try:
        import ctypes
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def get_npcap_version() -> str:
    """Return Npcap version string if installed, else empty string."""
    if not WIN:
        return ""
    try:
        import winreg
        key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                             r"SOFTWARE\Npcap", 0, winreg.KEY_READ)
        ver, _ = winreg.QueryValueEx(key, "DisplayVersion")
        winreg.CloseKey(key)
        return str(ver)
    except Exception:
        return "installed (version unknown)"


# ─────────────────────────────────────────────────────────────────────────────
# Download + install (runs on a background thread)
# ─────────────────────────────────────────────────────────────────────────────
class NpcapInstaller:
    """
    Download Npcap installer and launch it.

    on_progress(pct: int, msg: str)  — called during download
    on_done(success: bool, msg: str) — called when install completes / fails
    """

    def __init__(self,
                 on_progress: Optional[Callable[[int, str], None]] = None,
                 on_done: Optional[Callable[[bool, str], None]] = None,
                 silent: bool = False):
        self._on_progress = on_progress or (lambda p, m: None)
        self._on_done     = on_done     or (lambda ok, m: None)
        self._silent      = silent
        self._thread: Optional[threading.Thread] = None

    def start(self) -> None:
        """Launch installer download + execution in a background thread."""
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def _run(self) -> None:
        try:
            self._on_progress(0, "Connecting to npcap.com…")
            import urllib.request, urllib.error

            tmp_dir = tempfile.mkdtemp(prefix="omnifi_npcap_")
            installer_path = os.path.join(tmp_dir, "npcap-installer.exe")

            # Stream download with progress
            try:
                req = urllib.request.Request(
                    NPCAP_URL,
                    headers={"User-Agent": "OmniFi-Installer/2.0"}
                )
                with urllib.request.urlopen(req, timeout=30) as resp:
                    total = int(resp.headers.get("Content-Length", 0))
                    downloaded = 0
                    chunk = 8192
                    with open(installer_path, "wb") as f:
                        while True:
                            data = resp.read(chunk)
                            if not data:
                                break
                            f.write(data)
                            downloaded += len(data)
                            if total:
                                pct = int(downloaded * 100 / total)
                                self._on_progress(
                                    pct,
                                    f"Downloading Npcap… {downloaded // 1024} KB"
                                    f" / {total // 1024} KB")
            except urllib.error.URLError as e:
                self._on_done(False,
                              f"Download failed: {e}\n\n"
                              f"Please download manually from:\n{NPCAP_URL}\n"
                              f"and install with WinPcap API-compatible mode enabled.")
                return

            self._on_progress(100, "Download complete. Launching installer…")

            # Launch installer
            if self._silent and is_admin():
                args = [installer_path] + NPCAP_SILENT_ARGS
                proc = subprocess.run(args, timeout=120)
                if proc.returncode == 0:
                    self._on_done(True,
                                  "Npcap installed successfully in silent mode.\n"
                                  "Restart OmniFi to enable full packet capture.")
                else:
                    self._on_done(False,
                                  f"Silent install failed (code {proc.returncode}).\n"
                                  f"Please run the installer manually:\n{installer_path}")
            else:
                # Interactive install (UAC prompt will appear)
                if WIN:
                    import ctypes
                    ctypes.windll.shell32.ShellExecuteW(
                        None, "runas", installer_path, None, None, 1)
                else:
                    subprocess.Popen([installer_path])
                self._on_done(True,
                              "Npcap installer launched.\n\n"
                              "✔ Check 'WinPcap API-compatible mode' during install.\n"
                              "After install completes, restart OmniFi as Administrator.")

        except Exception as e:
            self._on_done(False, f"Install error: {e}")


# ─────────────────────────────────────────────────────────────────────────────
# Qt dialog (shown at startup if Npcap missing on Windows)
# ─────────────────────────────────────────────────────────────────────────────
def show_npcap_dialog(parent=None) -> None:
    """
    Show a non-blocking Npcap install dialog.
    Call from main() on Windows when is_npcap_installed() is False.
    """
    if not WIN:
        return
    try:
        from PyQt6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout,
                                      QLabel, QPushButton, QProgressBar,
                                      QApplication)
        from PyQt6.QtCore import Qt, pyqtSignal, QObject

        class _Sig(QObject):
            progress = pyqtSignal(int, str)
            done     = pyqtSignal(bool, str)

        sig = _Sig()

        dlg = QDialog(parent)
        dlg.setWindowTitle("OmniFi — Npcap Required")
        dlg.setFixedWidth(460)
        dlg.setStyleSheet("""
            QDialog { background: #0e1320; color: #c0d0f0; }
            QLabel  { color: #c0d0f0; }
            QPushButton { background: #1e3050; color: #80aaff;
                          border: 1px solid #2a4070; border-radius: 5px;
                          padding: 6px 14px; font-size: 11px; }
            QPushButton:hover { background: #2a4070; }
            QProgressBar { background: #1a2030; border-radius: 4px; text-align: center; }
            QProgressBar::chunk { background: #00c8ff; border-radius: 4px; }
        """)

        lay = QVBoxLayout(dlg)
        lay.setContentsMargins(20, 18, 20, 18)
        lay.setSpacing(10)

        lay.addWidget(QLabel(
            "⚠️  <b>Npcap not detected</b><br>"
            "Npcap is required for:<br>"
            "• Deauth / Beacon anomaly / DHCP rogue detection<br>"
            "• Cleartext credential sniffer<br>"
            "• ARP MITM packet-level analysis<br><br>"
            "<i>OmniFi will work without Npcap, but these modules will be limited.<br>"
            "ARP / DNS / ICMP / Captive Portal detection do NOT require Npcap.</i>",
            wordWrap=True))

        pbar = QProgressBar()
        pbar.setRange(0, 100)
        pbar.setValue(0)
        pbar.setVisible(False)
        lay.addWidget(pbar)

        status = QLabel("")
        status.setWordWrap(True)
        status.setStyleSheet("color: #80aaff; font-size: 10px;")
        lay.addWidget(status)

        btns = QHBoxLayout()
        btn_install = QPushButton("⬇ Download & Install Npcap")
        btn_install.setStyleSheet(
            "background: #003319; color: #00e676; border: 1px solid #00c853; "
            "border-radius: 5px; padding: 6px 16px; font-weight: 600;")
        btn_skip = QPushButton("Skip — continue without Npcap")
        btns.addWidget(btn_install); btns.addWidget(btn_skip)
        lay.addLayout(btns)

        installer: list = [None]

        def _on_progress(pct: int, msg: str):
            sig.progress.emit(pct, msg)

        def _on_done(ok: bool, msg: str):
            sig.done.emit(ok, msg)

        sig.progress.connect(lambda p, m: (pbar.setValue(p), status.setText(m)))
        sig.done.connect(lambda ok, m: (
            status.setText(m),
            status.setStyleSheet(f"color: {'#00e676' if ok else '#f44336'}; font-size: 10px;"),
            btn_install.setEnabled(True),
            btn_install.setText("✔ Install launched") if ok else None,
            pbar.setVisible(False),
        ))

        def _start_install():
            btn_install.setEnabled(False)
            pbar.setVisible(True)
            inst = NpcapInstaller(on_progress=_on_progress, on_done=_on_done)
            installer[0] = inst
            inst.start()

        btn_install.clicked.connect(_start_install)
        btn_skip.clicked.connect(dlg.accept)

        dlg.exec()
    except ImportError:
        log.warning("[Npcap] PyQt6 not available for dialog")
