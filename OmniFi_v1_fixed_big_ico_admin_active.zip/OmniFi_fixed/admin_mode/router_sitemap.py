"""
OmniFi — Router Configuration Sitemap & Multi-Vendor Enforcement
=================================================================
Maintains a per-ISP/vendor sitemap of router configuration endpoints
so the enforcement engine can navigate directly to any setting page
without having to scrape every time.

Supports:
  JioFiber (ZTE F670/H2)  · JioFi MiFi  · Airtel (Huawei HG8145)
  BSNL (Netlink/Syrotech/DASAN)  · ACT (TP-Link/D-Link/Tenda)
  Tata Play  · Hathway  · Excitel  · RailWire  · MTNL
  Generic OpenWRT/DD-WRT/Tomato fallback

Each ISP entry maps capability → (endpoint_path, method, payload_template)
so the EnforcementEngine can push any setting directly.
"""

import re
import logging
import requests

requests.packages.urllib3.disable_warnings()
log = logging.getLogger("OmniFi.RouterSitemap")

# ─────────────────────────────────────────────────────────────────────────────
# Capability identifiers (used as keys by EnforcementEngine)
# ─────────────────────────────────────────────────────────────────────────────
CAP_MAC_BLOCK     = "mac_block"
CAP_MAC_ALLOW     = "mac_allow"
CAP_WIFI_PASSWORD = "wifi_password"
CAP_WIFI_SSID     = "wifi_ssid"
CAP_WIFI_BAND     = "wifi_band"
CAP_WIFI_CHANNEL  = "wifi_channel"
CAP_WIFI_PROTOCOL = "wifi_protocol"    # WPA2/WPA3
CAP_PMF           = "pmf_enable"
CAP_WPS           = "wps_disable"
CAP_MAX_CLIENTS   = "max_clients"
CAP_GUEST_NET     = "guest_network"
CAP_DNS_OVERRIDE  = "dns_override"
CAP_REMOTE_MGMT   = "remote_mgmt"
CAP_FIREWALL      = "firewall_rule"
CAP_REBOOT        = "reboot"
CAP_DEVICE_LIST   = "device_list"
CAP_QUARANTINE    = "quarantine"
CAP_PARENTAL      = "parental_control"
CAP_BANDWIDTH     = "bandwidth_limit"


# ─────────────────────────────────────────────────────────────────────────────
# Per-vendor sitemap definitions
# Format: cap_id → {path, method, content_type, payload_fn(args) → dict/str}
# ─────────────────────────────────────────────────────────────────────────────

SITEMAPS = {

    # ── JioFiber (ZTE F670 / H2-series) ──────────────────────────────────────
    "jiofiber": {
        "panel_paths": ["/login.html", "/main.html", "/wireless.html"],
        CAP_MAC_BLOCK: {
            "paths": ["/cgi-bin/cgiSrv.cgi", "/goform/setSecurity"],
            "method": "POST",
            "ct": "form",
            "payload": lambda mac, **_: {"cmd":"SET_MAC_FILTER","mac":mac,"action":"block","enable":"1"},
        },
        CAP_MAC_ALLOW: {
            "paths": ["/cgi-bin/cgiSrv.cgi"],
            "method": "POST",
            "ct": "form",
            "payload": lambda mac, **_: {"cmd":"SET_MAC_FILTER","mac":mac,"action":"allow"},
        },
        CAP_WIFI_PASSWORD: {
            "paths": ["/goform/setWifi", "/cgi-bin/cgiSrv.cgi"],
            "method": "POST",
            "ct": "form",
            "payload": lambda pw, band="2.4", **_: {
                "cmd":"SET_WIFI_PASS","wifiPwd":pw,
                "wifiIndex":"0" if band=="2.4" else "1"},
        },
        CAP_WIFI_SSID: {
            "paths": ["/goform/setWifi"],
            "method": "POST",
            "ct": "form",
            "payload": lambda ssid, band="2.4", **_: {
                "cmd":"SET_WIFI_SSID","wifiSSID":ssid,
                "wifiIndex":"0" if band=="2.4" else "1"},
        },
        CAP_WPS: {
            "paths": ["/goform/setWps", "/cgi-bin/cgiSrv.cgi"],
            "method": "POST",
            "ct": "form",
            "payload": lambda **_: {"cmd":"SET_WPS","wpsEnable":"0"},
        },
        CAP_REBOOT: {
            "paths": ["/cgi-bin/cgiSrv.cgi"],
            "method": "POST",
            "ct": "form",
            "payload": lambda **_: {"cmd":"REBOOT"},
        },
        CAP_DEVICE_LIST: {
            "paths": ["/cgi-bin/cgiSrv.cgi"],
            "method": "POST",
            "ct": "form",
            "payload": lambda **_: {"cmd":"GET_DEVICE_LIST"},
        },
        CAP_MAX_CLIENTS: {
            "paths": ["/goform/setWifi"],
            "method": "POST",
            "ct": "form",
            "payload": lambda n, **_: {"cmd":"SET_MAX_CLIENTS","maxClients":str(n)},
        },
    },

    # ── JioAirFiber ───────────────────────────────────────────────────────────
    "jioairfiber": {
        "panel_paths": ["/login.html"],
        CAP_MAC_BLOCK: {
            "paths": ["/cgi-bin/cgiSrv.cgi"],
            "method": "POST", "ct": "form",
            "payload": lambda mac, **_: {"cmd":"SET_MAC_FILTER","mac":mac,"action":"block","enable":"1"},
        },
        CAP_MAC_ALLOW: {
            "paths": ["/cgi-bin/cgiSrv.cgi"],
            "method": "POST", "ct": "form",
            "payload": lambda mac, **_: {"cmd":"SET_MAC_FILTER","mac":mac,"action":"allow"},
        },
        CAP_REBOOT: {
            "paths": ["/cgi-bin/cgiSrv.cgi"],
            "method": "POST", "ct": "form",
            "payload": lambda **_: {"cmd":"REBOOT"},
        },
    },

    # ── Airtel (Huawei HG8145V5 / HG8240 / Nokia G-240W) ─────────────────────
    "airtel": {
        "panel_paths": ["/", "/html/index.html"],
        CAP_MAC_BLOCK: {
            "paths": ["/api/ntwk/mac_filter", "/html/amp/api/mac_filter"],
            "method": "POST", "ct": "json",
            "payload": lambda mac, **_: {"mac":mac,"enable":True,"type":"black"},
        },
        CAP_MAC_ALLOW: {
            "paths": ["/api/ntwk/mac_filter"],
            "method": "DELETE", "ct": "json",
            "payload": lambda mac, **_: {"mac":mac},
        },
        CAP_WIFI_PASSWORD: {
            "paths": ["/api/ntwk/wlanbasic"],
            "method": "PUT", "ct": "json",
            "payload": lambda pw, band="2.4", **_: {
                "WifiBasicInfo":{"PreSharedKey":pw},
                "InstanceID":"1" if band=="2.4" else "5"},
        },
        CAP_WIFI_SSID: {
            "paths": ["/api/ntwk/wlanbasic"],
            "method": "PUT", "ct": "json",
            "payload": lambda ssid, band="2.4", **_: {
                "WifiBasicInfo":{"SSID":ssid},
                "InstanceID":"1" if band=="2.4" else "5"},
        },
        CAP_PMF: {
            "paths": ["/api/ntwk/wlansecurity"],
            "method": "PUT", "ct": "json",
            "payload": lambda enable=True, **_: {"ManagementFrameProtect":"2" if enable else "0"},
        },
        CAP_WPS: {
            "paths": ["/api/ntwk/wps"],
            "method": "PUT", "ct": "json",
            "payload": lambda **_: {"WPSEnable":False},
        },
        CAP_GUEST_NET: {
            "paths": ["/api/ntwk/guestnetwork"],
            "method": "PUT", "ct": "json",
            "payload": lambda enable=True, ssid="OmniFi-Guest", **_: {
                "GuestNetworkEnabled":enable,"SSID":ssid,"MaxClients":5},
        },
        CAP_DNS_OVERRIDE: {
            "paths": ["/api/ntwk/dns"],
            "method": "PUT", "ct": "json",
            "payload": lambda dns1="1.1.1.1", dns2="8.8.8.8", **_: {
                "PrimaryDNS":dns1,"SecondaryDNS":dns2},
        },
        CAP_DEVICE_LIST: {
            "paths": ["/api/ntwk/hostinfo"],
            "method": "GET", "ct": "json",
            "payload": lambda **_: None,
        },
        CAP_BANDWIDTH: {
            "paths": ["/api/ntwk/qos"],
            "method": "PUT", "ct": "json",
            "payload": lambda mac, down_kbps=0, up_kbps=0, **_: {
                "MACAddress":mac,"DownloadRate":down_kbps,"UploadRate":up_kbps},
        },
        CAP_REBOOT: {
            "paths": ["/api/ntwk/reboot"],
            "method": "POST", "ct": "json",
            "payload": lambda **_: {},
        },
        CAP_REMOTE_MGMT: {
            "paths": ["/api/ntwk/remotemanage"],
            "method": "PUT", "ct": "json",
            "payload": lambda enable=False, **_: {"RemoteManageEnable":enable},
        },
    },

    # ── BSNL (Netlink / Syrotech / DASAN ONT) ────────────────────────────────
    "bsnl_ftth": {
        "panel_paths": ["/", "/userRpm/index.htm"],
        CAP_MAC_BLOCK: {
            "paths": ["/userRpm/WlanMacFilterRpm.htm",
                      "/cgi-bin/macsec.cgi",
                      "/apply.cgi"],
            "method": "POST", "ct": "form",
            "payload": lambda mac, **_: {
                "mac_addr":mac,"filter_type":"deny",
                "action":"add","submit_button":"Save"},
        },
        CAP_WIFI_PASSWORD: {
            "paths": ["/userRpm/WlanSecurityRpm.htm", "/cgi-bin/wlsecurity.cgi"],
            "method": "POST", "ct": "form",
            "payload": lambda pw, **_: {"wpapsk":pw,"wpa2psk":pw,"submit_button":"Save"},
        },
        CAP_WPS: {
            "paths": ["/userRpm/WlanWpsRpm.htm"],
            "method": "POST", "ct": "form",
            "payload": lambda **_: {"wps_enable":"0","submit_button":"Save"},
        },
        CAP_REBOOT: {
            "paths": ["/userRpm/SysRebootRpm.htm","/cgi-bin/reboot.cgi"],
            "method": "POST", "ct": "form",
            "payload": lambda **_: {"submit_button":"Reboot"},
        },
        CAP_DNS_OVERRIDE: {
            "paths": ["/userRpm/WanDynamicIpCfgRpm.htm"],
            "method": "POST", "ct": "form",
            "payload": lambda dns1="1.1.1.1", dns2="8.8.8.8", **_: {
                "dns1":dns1,"dns2":dns2,"submit_button":"Save"},
        },
    },

    # ── ACT Fibernet (TP-Link / D-Link / Tenda) ───────────────────────────────
    "act": {
        "panel_paths": ["/", "/cgi-bin/luci/"],
        # TP-Link stok-based
        CAP_MAC_BLOCK: {
            "paths": ["/cgi-bin/luci/;stok={stok}/admin/wireless",
                      "/userRpm/AccessCtrlAccessRulesRpm.htm"],
            "method": "POST", "ct": "json",
            "payload": lambda mac, stok="", **_: {
                "method":"add","params":{"mac":mac,"type":"black"}},
        },
        CAP_WIFI_PASSWORD: {
            "paths": ["/cgi-bin/luci/;stok={stok}/admin/wireless"],
            "method": "POST", "ct": "json",
            "payload": lambda pw, stok="", **_: {
                "method":"set","params":{"wireless":{"psk":pw}}},
        },
        CAP_WPS: {
            "paths": ["/cgi-bin/luci/;stok={stok}/admin/wireless"],
            "method": "POST", "ct": "json",
            "payload": lambda stok="", **_: {
                "method":"set","params":{"wps":{"wps_state":"0"}}},
        },
        CAP_REBOOT: {
            "paths": ["/cgi-bin/luci/;stok={stok}/admin/reboot"],
            "method": "POST", "ct": "json",
            "payload": lambda stok="", **_: {"method":"set","params":{}},
        },
        CAP_MAX_CLIENTS: {
            "paths": ["/cgi-bin/luci/;stok={stok}/admin/wireless"],
            "method": "POST", "ct": "json",
            "payload": lambda n, stok="", **_: {
                "method":"set","params":{"wireless":{"max_sta":n}}},
        },
        CAP_DNS_OVERRIDE: {
            "paths": ["/cgi-bin/luci/;stok={stok}/admin/network"],
            "method": "POST", "ct": "json",
            "payload": lambda dns1, dns2, stok="", **_: {
                "method":"set","params":{"dns":{"dns1":dns1,"dns2":dns2}}},
        },
        CAP_DEVICE_LIST: {
            "paths": ["/cgi-bin/luci/;stok={stok}/admin/wireless"],
            "method": "POST", "ct": "json",
            "payload": lambda stok="", **_: {"method":"get","params":{"hosts_info":{}}},
        },
    },

    # ── Generic OpenWRT / LuCI ────────────────────────────────────────────────
    "openwrt": {
        "panel_paths": ["/cgi-bin/luci/"],
        CAP_MAC_BLOCK: {
            "paths": ["/cgi-bin/luci/admin/network/wireless"],
            "method": "POST", "ct": "json",
            "payload": lambda mac, **_: {"method":"add","params":{"mac":mac,"type":"block"}},
        },
        CAP_WIFI_PASSWORD: {
            "paths": ["/cgi-bin/luci/admin/network/wireless"],
            "method": "POST", "ct": "json",
            "payload": lambda pw, **_: {"method":"set","params":{"key":pw}},
        },
        CAP_WPS: {
            "paths": ["/cgi-bin/luci/admin/network/wireless"],
            "method": "POST", "ct": "json",
            "payload": lambda **_: {"method":"set","params":{"wps":{"enabled":False}}},
        },
        CAP_REBOOT: {
            "paths": ["/cgi-bin/luci/admin/system/reboot"],
            "method": "POST", "ct": "form",
            "payload": lambda **_: {"reboot":"Perform reboot"},
        },
        CAP_FIREWALL: {
            "paths": ["/cgi-bin/luci/admin/network/firewall/rules"],
            "method": "POST", "ct": "form",
            "payload": lambda mac, action="DROP", **_: {
                "src_mac":mac,"target":action,"submit":"Save"},
        },
        CAP_DNS_OVERRIDE: {
            "paths": ["/cgi-bin/luci/admin/network/dhcp"],
            "method": "POST", "ct": "form",
            "payload": lambda dns1, dns2="", **_: {
                "dns":f"{dns1},{dns2}".rstrip(","),"submit":"Save"},
        },
        CAP_PARENTAL: {
            "paths": ["/cgi-bin/luci/admin/network/parental"],
            "method": "POST", "ct": "form",
            "payload": lambda mac, deny_all=True, **_: {
                "mac":mac,"deny":str(deny_all).lower(),"submit":"Save"},
        },
    },

    # ── Generic DD-WRT ────────────────────────────────────────────────────────
    "ddwrt": {
        "panel_paths": ["/"],
        CAP_MAC_BLOCK: {
            "paths": ["/apply.cgi"],
            "method": "POST", "ct": "form",
            "payload": lambda mac, **_: {
                "action":"ApplyTake","submit_button":"WL_FilterTable",
                "mac_addr":mac,"filter_mode":"deny"},
        },
        CAP_WIFI_PASSWORD: {
            "paths": ["/apply.cgi"],
            "method": "POST", "ct": "form",
            "payload": lambda pw, **_: {
                "action":"ApplyTake","submit_button":"Wireless_WPA",
                "wl_wpa_psk":pw},
        },
        CAP_WPS: {
            "paths": ["/apply.cgi"],
            "method": "POST", "ct": "form",
            "payload": lambda **_: {
                "action":"ApplyTake","submit_button":"WL_WPS","wps_enable":"0"},
        },
        CAP_REBOOT: {
            "paths": ["/apply.cgi"],
            "method": "POST", "ct": "form",
            "payload": lambda **_: {"action":"Reboot"},
        },
    },
}

# Aliases
SITEMAPS["jiofi_dongle"] = SITEMAPS["jiofiber"]
SITEMAPS["bsnl_adsl"]    = SITEMAPS["bsnl_ftth"]
SITEMAPS["hathway"]      = SITEMAPS["ddwrt"]
SITEMAPS["excitel"]      = SITEMAPS["act"]
SITEMAPS["railwire"]     = SITEMAPS["bsnl_ftth"]
SITEMAPS["mtnl"]         = SITEMAPS["bsnl_ftth"]
SITEMAPS["tataplay"]     = SITEMAPS["act"]


SITEMAPS["dasan_bsnl"] = {
    "panel_paths": ["/", "/cgi-bin/index.asp"],
    CAP_MAC_BLOCK: {
        "paths": ["/cgi-bin/index.asp"],
        "method": "POST",
        "content_type": "form",
        "payload_fn": lambda mac, **kw: {
            "AccessType": "deny", "MACAddress": mac,
            "Action": "Add", "submit": "Apply",
        },
        "note": "MAC filter → Firewall Setup → MAC Filter",
    },
    CAP_MAC_ALLOW: {
        "paths": ["/cgi-bin/index.asp"],
        "method": "POST",
        "content_type": "form",
        "payload_fn": lambda mac, **kw: {
            "AccessType": "allow", "MACAddress": mac,
            "Action": "Add", "submit": "Apply",
        },
    },
    CAP_WIFI_PASSWORD: {
        "paths": ["/cgi-bin/index.asp"],
        "method": "POST",
        "content_type": "form",
        "payload_fn": lambda password, band="2.4", **kw: {
            "wl_wpa_psk": password, "submit": "Apply",
        },
        "note": "Wi-Fi Setup → Wireless Security",
    },
    CAP_WIFI_SSID: {
        "paths": ["/cgi-bin/index.asp"],
        "method": "POST",
        "content_type": "form",
        "payload_fn": lambda ssid, **kw: {"wl_ssid": ssid, "submit": "Apply"},
    },
    CAP_WPS: {
        "paths": ["/cgi-bin/index.asp"],
        "method": "POST",
        "content_type": "form",
        "payload_fn": lambda **kw: {"wl_wps_mode": "disabled", "submit": "Apply"},
        "note": "Wi-Fi Setup → WPS",
    },
    CAP_REBOOT: {
        "paths": ["/cgi-bin/index.asp"],
        "method": "POST",
        "content_type": "form",
        "payload_fn": lambda **kw: {"action": "reboot", "submit": "Reboot"},
        "note": "Save/Reboot → Reboot",
    },
    CAP_DNS_OVERRIDE: {
        "paths": ["/cgi-bin/index.asp"],
        "method": "POST",
        "content_type": "form",
        "payload_fn": lambda primary="1.1.1.1", secondary="8.8.8.8", **kw: {
            "dns1": primary, "dns2": secondary, "submit": "Apply",
        },
        "note": "Advanced Setup → LAN → DNS",
    },
    CAP_MAX_CLIENTS: {
        "paths": ["/cgi-bin/index.asp"],
        "method": "POST",
        "content_type": "form",
        "payload_fn": lambda n=16, **kw: {"wl_sta_max": str(n), "submit": "Apply"},
        "note": "Wi-Fi Setup → Max Stations",
    },
}
SITEMAPS["dasan_zhone"] = SITEMAPS["dasan_bsnl"]
SITEMAPS["bsnl_ftth"]["_dasan_alias"] = True   # BSNL FTTH may also be DASAN


# ─────────────────────────────────────────────────────────────────────────────
# RouterConfigManager — executes capabilities against a live session
# ─────────────────────────────────────────────────────────────────────────────


# Generic / OpenWRT / DD-WRT fallback sitemap
SITEMAPS["generic"] = {
    "panel_paths": ["/", "/index.asp", "/index.html"],
    CAP_MAC_BLOCK: {
        "paths": ["/cgi-bin/cgi.cgi", "/goform/setSecurity", "/wifi_mac_filter.asp"],
        "method": "POST", "content_type": "form",
        "payload_fn": lambda mac="", **kw: {"mac": mac, "action": "block", "enable": "1"},
        "note": "MAC Filter — Block",
    },
    CAP_MAC_ALLOW: {
        "paths": ["/cgi-bin/cgi.cgi", "/goform/setSecurity", "/wifi_mac_filter.asp"],
        "method": "POST", "content_type": "form",
        "payload_fn": lambda mac="", **kw: {"mac": mac, "action": "allow", "enable": "1"},
        "note": "MAC Filter — Allow",
    },
    CAP_WPS: {
        "paths": ["/cgi-bin/cgi.cgi", "/goform/setWPS", "/wireless_wps.asp"],
        "method": "POST", "content_type": "form",
        "payload_fn": lambda **kw: {"wps_enable": "0", "action": "disable_wps"},
        "note": "Disable WPS",
    },
    CAP_PMF: {
        "paths": ["/cgi-bin/cgi.cgi", "/goform/setWireless"],
        "method": "POST", "content_type": "form",
        "payload_fn": lambda **kw: {"pmf": "2", "ieee80211w": "2"},
        "note": "Enable PMF/802.11w",
    },
    CAP_WIFI_PASSWORD: {
        "paths": ["/cgi-bin/cgi.cgi", "/goform/setWireless", "/wireless_security.asp"],
        "method": "POST", "content_type": "form",
        "payload_fn": lambda password="", band="both", **kw: {
            "wpa_psk": password, "wpaPsk": password, "wl_wpa_psk": password,
            "band": band, "action": "Apply"},
        "note": "Wi-Fi Password Change",
    },
    CAP_WIFI_PROTOCOL: {
        "paths": ["/cgi-bin/cgi.cgi", "/goform/setWireless"],
        "method": "POST", "content_type": "form",
        "payload_fn": lambda mode="WPA2-PSK", **kw: {
            "security_mode": mode, "wl_auth_mode_x": mode, "action": "Apply"},
        "note": "Wi-Fi Security Protocol",
    },
    CAP_DNS_OVERRIDE: {
        "paths": ["/cgi-bin/cgi.cgi", "/goform/setLAN", "/lan.asp"],
        "method": "POST", "content_type": "form",
        "payload_fn": lambda primary="1.1.1.1", secondary="1.0.0.1", **kw: {
            "dns1": primary, "dns2": secondary,
            "wan_dns1": primary, "wan_dns2": secondary, "action": "Apply"},
        "note": "DNS Override",
    },
    CAP_REMOTE_MGMT: {
        "paths": ["/cgi-bin/cgi.cgi", "/goform/setMgmt", "/management.asp"],
        "method": "POST", "content_type": "form",
        "payload_fn": lambda **kw: {"remote_mgt_enable": "0", "wan_mgt_enable": "0",
                                    "action": "Apply"},
        "note": "Disable Remote Management",
    },
    CAP_MAX_CLIENTS: {
        "paths": ["/cgi-bin/cgi.cgi", "/goform/setWireless"],
        "method": "POST", "content_type": "form",
        "payload_fn": lambda n=16, **kw: {"wl_sta_max": str(n), "action": "Apply"},
        "note": "Max Connected Clients",
    },
    CAP_REBOOT: {
        "paths": ["/cgi-bin/cgi.cgi", "/goform/Reboot", "/reboot.asp"],
        "method": "POST", "content_type": "form",
        "payload_fn": lambda **kw: {"action": "reboot"},
        "note": "Router Reboot",
    },
    CAP_DEVICE_LIST: {
        "paths": ["/status.asp", "/connected.asp", "/cgi-bin/status.cgi"],
        "method": "GET", "content_type": "form",
        "payload_fn": None,
        "note": "Connected Device List",
    },
    CAP_FIREWALL: {
        "paths": ["/cgi-bin/cgi.cgi", "/goform/setFirewall"],
        "method": "POST", "content_type": "form",
        "payload_fn": lambda mac="", action="DROP", **kw: {
            "mac": mac, "firewall_action": action, "action": "Apply"},
        "note": "Firewall Rule",
    },
    CAP_PARENTAL: {
        "paths": ["/cgi-bin/cgi.cgi", "/goform/setParental"],
        "method": "POST", "content_type": "form",
        "payload_fn": lambda mac="", **kw: {"mac": mac, "block": "1", "action": "Apply"},
        "note": "Parental Control Block",
    },
}


class RouterConfigManager:
    """
    Executes router configuration capabilities against a live authenticated session.
    Handles all vendor/ISP differences through the SITEMAPS dictionary.
    Falls back gracefully if a specific endpoint fails.
    """

    def __init__(self, session: requests.Session, base_url: str,
                 isp_key: str = "generic"):
        self._session  = session
        self._base     = base_url.rstrip("/")
        self._isp_key  = isp_key
        self._sitemap  = SITEMAPS.get(isp_key) or SITEMAPS.get("generic", {})
        log.info(f"RouterConfigManager init: isp={isp_key}, base={self._base}")

    # ── Public helpers ────────────────────────────────────────────────────────

    def get_capabilities(self) -> list[str]:
        """Return list of capability IDs supported for this ISP."""
        return [k for k in self._sitemap.keys() if not k.startswith("_")]

    def get_device_list(self) -> list[dict]:
        """Fetch connected devices from router DHCP/station list page."""
        cap = self._sitemap.get(CAP_DEVICE_LIST, {})
        paths = cap.get("paths", ["/status.asp", "/connected_devices.asp",
                                   "/cgi-bin/status.cgi"])
        for path in paths:
            try:
                r = self._session.get(self._base + path, timeout=8, verify=False)
                if r.status_code == 200:
                    return self._parse_device_table(r.text)
            except Exception:
                continue
        return []

    # ── Capability implementations ────────────────────────────────────────────

    def mac_block(self, mac: str) -> dict:
        return self._apply_cap(CAP_MAC_BLOCK, mac=mac)

    def mac_allow(self, mac: str) -> dict:
        return self._apply_cap(CAP_MAC_ALLOW, mac=mac)

    def disable_wps(self) -> dict:
        return self._apply_cap(CAP_WPS)

    def enable_pmf(self) -> dict:
        return self._apply_cap(CAP_PMF)

    def set_wifi_password(self, password: str, band: str = "both") -> dict:
        if len(password) < 8:
            return {"ok": False, "detail": "Password must be at least 8 characters"}
        return self._apply_cap(CAP_WIFI_PASSWORD, password=password, band=band)

    def set_wifi_ssid(self, ssid: str, band: str = "both") -> dict:
        return self._apply_cap(CAP_WIFI_SSID, ssid=ssid, band=band)

    def set_wifi_protocol(self, mode: str) -> dict:
        """mode: WPA3, WPA3-WPA2, WPA2-PSK, WPA-PSK"""
        return self._apply_cap(CAP_WIFI_PROTOCOL, mode=mode)

    def set_dns(self, dns1: str = "1.1.1.1", dns2: str = "1.0.0.1") -> dict:
        return self._apply_cap(CAP_DNS_OVERRIDE, primary=dns1, secondary=dns2)

    def disable_remote_mgmt(self) -> dict:
        return self._apply_cap(CAP_REMOTE_MGMT)

    def set_max_clients(self, n: int = 16) -> dict:
        return self._apply_cap(CAP_MAX_CLIENTS, n=n)

    def add_firewall_rule(self, mac: str, action: str = "DROP") -> dict:
        return self._apply_cap(CAP_FIREWALL, mac=mac, action=action)

    def parental_block(self, mac: str) -> dict:
        return self._apply_cap(CAP_PARENTAL, mac=mac)

    def set_bandwidth_limit(self, mac: str, down_kbps: int, up_kbps: int) -> dict:
        return self._apply_cap(CAP_BANDWIDTH, mac=mac,
                               down_kbps=down_kbps, up_kbps=up_kbps)

    def enable_guest_network(self, ssid: str, password: str) -> dict:
        return self._apply_cap(CAP_GUEST_NET, ssid=ssid, password=password)

    def reboot(self) -> dict:
        return self._apply_cap(CAP_REBOOT)

    def quarantine_device(self, mac: str) -> dict:
        return self._apply_cap(CAP_QUARANTINE, mac=mac)

    # ── Core dispatcher ───────────────────────────────────────────────────────

    def _apply_cap(self, cap_id: str, **kwargs) -> dict:
        """
        Look up capability in sitemap and POST to each listed path until
        one succeeds. Falls back to 'generic' sitemap if ISP-specific fails.
        """
        cap = self._sitemap.get(cap_id)
        if not cap:
            # Try generic fallback
            cap = SITEMAPS.get("generic", {}).get(cap_id)
        if not cap:
            return {"ok": False,
                    "detail": f"Capability '{cap_id}' not mapped for {self._isp_key}"}

        paths   = cap.get("paths", [])
        method  = cap.get("method", "POST").upper()
        ct      = cap.get("content_type", "form")
        payload_fn = cap.get("payload_fn")
        note    = cap.get("note", cap_id)

        last_error = "No paths configured"
        for path in paths:
            url = self._base + path
            try:
                payload = payload_fn(**kwargs) if (payload_fn and kwargs) else \
                          (payload_fn() if payload_fn else {})
                if method == "POST":
                    if ct == "json":
                        r = self._session.post(url, json=payload,
                                               timeout=10, verify=False)
                    else:
                        r = self._session.post(url, data=payload,
                                               timeout=10, verify=False)
                else:
                    r = self._session.get(url, params=payload,
                                          timeout=10, verify=False)

                if r.status_code in (200, 204, 302):
                    log.info(f"[RouterConfig] {cap_id} → {url} ✓ ({r.status_code})")
                    return {"ok": True,
                            "detail": f"{note} applied via {path}",
                            "status_code": r.status_code}
                else:
                    last_error = f"HTTP {r.status_code} from {path}"
                    log.warning(f"[RouterConfig] {cap_id} → {url} ✗ ({r.status_code})")

            except requests.exceptions.ConnectTimeout:
                last_error = f"Timeout connecting to {url}"
            except requests.exceptions.ConnectionError:
                last_error = f"Connection refused at {url}"
            except Exception as e:
                last_error = str(e)
                log.debug(f"[RouterConfig] {cap_id} path {path} error: {e}")

        return {"ok": False, "detail": f"{cap_id} failed — {last_error}"}

    # ── Device table parser ───────────────────────────────────────────────────

    def _parse_device_table(self, html: str) -> list[dict]:
        """Extract MAC/IP/hostname rows from any router HTML page."""
        import re as _re
        devices = []
        # Match MAC address patterns paired with adjacent IPs
        mac_pat = _re.compile(
            r'([0-9A-Fa-f]{2}[:\-][0-9A-Fa-f]{2}[:\-][0-9A-Fa-f]{2}'
            r'[:\-][0-9A-Fa-f]{2}[:\-][0-9A-Fa-f]{2}[:\-][0-9A-Fa-f]{2})')
        ip_pat  = _re.compile(r'(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})')
        macs = mac_pat.findall(html)
        ips  = ip_pat.findall(html)
        # Filter out gateway/broadcast IPs
        ips = [ip for ip in ips if not ip.endswith('.0') and not ip.endswith('.255')]
        seen = set()
        for i, mac in enumerate(macs):
            mac_norm = mac.upper().replace("-", ":")
            if mac_norm in seen:
                continue
            seen.add(mac_norm)
            ip = ips[i] if i < len(ips) else ""
            devices.append({"mac": mac_norm, "ip": ip, "hostname": ""})
        return devices
