"""
OmniFi — UI Theme / Design System
===================================
Single source of truth for every colour, font, spacing, and QSS rule.
Import this module only. Never hard-code colours anywhere else.

Aesthetic: dark industrial terminal — scan-line precision, monospace data,
           colour-coded severity, crisp geometry.
"""

import platform
from PyQt6.QtGui  import QColor, QFont, QFontDatabase
from PyQt6.QtCore import Qt

# ── Platform ──────────────────────────────────────────────────────────────────
WIN = platform.system() == "Windows"

# ── Font families ─────────────────────────────────────────────────────────────
MONO  = "Consolas"       if WIN else "JetBrains Mono"
SANS  = "Segoe UI"       if WIN else "Ubuntu"
EMOJI = "Segoe UI Emoji" if WIN else "Noto Color Emoji"

def mf(size: int = 10, bold: bool = False) -> QFont:
    """Return a monospace font."""
    f = QFont(MONO, size)
    f.setStyleHint(QFont.StyleHint.Monospace)
    if bold: f.setWeight(QFont.Weight.Bold)
    return f

def sf(size: int = 10, bold: bool = False) -> QFont:
    """Return the sans-serif UI font."""
    f = QFont(SANS, size)
    if bold: f.setWeight(QFont.Weight.Bold)
    return f

def ef(size: int = 12) -> QFont:
    """Return an emoji font."""
    return QFont(EMOJI, size)

# ── Colour palette ────────────────────────────────────────────────────────────
# Backgrounds (darkest → lightest surface)
BG0  = "#07080d"
BG1  = "#0c0e16"
BG2  = "#10121c"
BG3  = "#161928"
BG4  = "#1c2035"

# Border / separator hierarchy
B1   = "#1e2440"
B2   = "#2a3258"
B3   = "#3a4470"

# Accent
ACC  = "#38bdf8"
ACC2 = "#0ea5e9"

# Semantic
RED  = "#f43f5e"
GRN  = "#22d3a0"
YLW  = "#fbbf24"
ORG  = "#fb7c3e"
PUR  = "#a78bfa"
PINK = "#f472b6"

# Text hierarchy
T1   = "#e8edf8"   # primary
T2   = "#8896b3"   # secondary
T3   = "#4a5572"   # muted
T4   = "#2a3252"   # very muted / placeholder

# Level → colour
LVL_C = {
    "critical": RED,
    "high":     ORG,
    "medium":   YLW,
    "low":      ACC,
    "ok":       GRN,
    "info":     T2,
}

# Verdict → colour
VDT_C = {
    "safe":       GRN,
    "acceptable": ACC,
    "caution":    YLW,
    "avoid":      ORG,
    "evil_twin":  RED,
}

# Level → weight (for trust score penalty)
LVL_W = {"critical": 30, "high": 20, "medium": 10, "low": 5, "ok": 0, "info": 0}


def rgba(hex_c: str, alpha: float) -> str:
    """Return CSS rgba() string from hex colour."""
    h = hex_c.lstrip("#")
    r, g, b = int(h[:2],16), int(h[2:4],16), int(h[4:],16)
    return f"rgba({r},{g},{b},{alpha})"

def qcolor(hex_c: str) -> QColor:
    return QColor(hex_c)


# ── Global application stylesheet ─────────────────────────────────────────────
APP_QSS = f"""
/* ── Base ── */
QWidget {{
    background: {BG1};
    color: {T1};
    font-family: "{SANS}";
    font-size: 12px;
}}
QMainWindow, QDialog {{
    background: {BG1};
}}
QLabel {{
    background: transparent;
    color: {T1};
}}

/* ── Buttons ── */
QPushButton {{
    background: {BG3};
    color: #ffffff;
    border: 1px solid {B2};
    border-radius: 6px;
    padding: 7px 16px;
    font-size: 12px;
    font-weight: 700;
    font-family: "{SANS}";
}}
QPushButton:hover   {{ background: {BG4}; border-color: {ACC}; color: #ffffff; }}
QPushButton:pressed {{ background: {BG2}; }}
QPushButton:disabled {{ color: {T4}; border-color: {B1}; }}

/* Primary CTA */
QPushButton[cls="primary"] {{
    background: {ACC2};
    color: #ffffff;
    border-color: {ACC};
    font-weight: bold;
    font-size: 12px;
}}
QPushButton[cls="primary"]:hover {{ background: {ACC}; }}
QPushButton[cls="primary"]:pressed {{ background: #0284c7; }}

/* Danger */
QPushButton[cls="danger"] {{
    background: {rgba(RED, 0.15)};
    color: #ffffff;
    background: {rgba(RED, 0.25)};
    border-color: {rgba(RED, 0.65)};
}}
QPushButton[cls="danger"]:hover {{ background: {rgba(RED, 0.28)}; }}

/* Success */
QPushButton[cls="success"] {{
    background: {rgba(GRN, 0.12)};
    color: #ffffff;
    background: {rgba(GRN, 0.20)};
    border-color: {rgba(GRN, 0.6)};
}}
QPushButton[cls="success"]:hover {{ background: {rgba(GRN, 0.22)}; }}

/* Warning */
QPushButton[cls="warn"] {{
    background: {rgba(YLW, 0.10)};
    color: #ffffff;
    background: {rgba(YLW, 0.18)};
    border-color: {rgba(YLW, 0.6)};
}}
QPushButton[cls="warn"]:hover {{ background: {rgba(YLW, 0.20)}; }}

/* Purple */
QPushButton[cls="purple"] {{
    background: {rgba(PUR, 0.12)};
    color: #ffffff;
    background: {rgba(PUR, 0.20)};
    border-color: {rgba(PUR, 0.6)};
}}

/* Ghost (transparent, border only) */
QPushButton[cls="ghost"] {{
    background: transparent;
    color: {T2};
    border-color: {B2};
}}
QPushButton[cls="ghost"]:hover {{ background: {BG3}; color: {T1}; }}

/* Icon-only (sidebar, toolbar) */
QPushButton[cls="icon"] {{
    background: transparent;
    border: none;
    padding: 4px;
    border-radius: 6px;
}}
QPushButton[cls="icon"]:hover {{ background: {BG3}; }}

/* ── Inputs ── */
QLineEdit, QTextEdit, QPlainTextEdit {{
    background: {BG3};
    color: {T1};
    border: 1px solid {B2};
    border-radius: 5px;
    padding: 6px 10px;
    font-family: "{MONO}";
    font-size: 11px;
    selection-background-color: {ACC2};
}}
QLineEdit:focus, QTextEdit:focus, QPlainTextEdit:focus {{
    border-color: {ACC};
    background: {BG4};
}}
QLineEdit:read-only {{ color: {T3}; background: {BG2}; }}
QLineEdit::placeholder {{ color: {T4}; }}

/* ── Table ── */
QTableWidget, QTableView {{
    background: {BG2};
    color: {T1};
    border: 1px solid {B1};
    gridline-color: {B1};
    border-radius: 6px;
    font-family: "{MONO}";
    font-size: 11px;
    alternate-background-color: {BG3};
    selection-background-color: {rgba(ACC, 0.18)};
    selection-color: {T1};
}}
QTableWidget::item {{ padding: 5px 10px; border: none; }}
QTableWidget::item:selected {{
    background: {rgba(ACC, 0.18)};
    color: {T1};
}}
QTableWidget::item:hover {{
    background: {rgba(T1, 0.04)};
}}
QHeaderView::section {{
    background: {BG1};
    color: {T3};
    border: none;
    border-bottom: 1px solid {B1};
    border-right: 1px solid {B1};
    padding: 7px 10px;
    font-family: "{MONO}";
    font-size: 10px;
    text-transform: uppercase;
    letter-spacing: 0.6px;
}}
QHeaderView::section:last {{ border-right: none; }}

/* ── Scrollbars ── */
QScrollBar:vertical {{
    background: {BG1};
    width: 7px;
    border-radius: 4px;
    margin: 0;
}}
QScrollBar::handle:vertical {{
    background: {B2};
    border-radius: 4px;
    min-height: 24px;
}}
QScrollBar::handle:vertical:hover {{ background: {B3}; }}
QScrollBar::add-line, QScrollBar::sub-line {{ height: 0; }}
QScrollBar:horizontal {{
    background: {BG1};
    height: 7px;
    border-radius: 4px;
}}
QScrollBar::handle:horizontal {{
    background: {B2};
    border-radius: 4px;
    min-width: 24px;
}}
QScrollBar::handle:horizontal:hover {{ background: {B3}; }}

/* ── Tabs ── */
QTabWidget::pane {{
    border: 1px solid {B1};
    background: {BG2};
    border-radius: 0 6px 6px 6px;
}}
QTabBar::tab {{
    background: {BG2};
    color: {T3};
    border: 1px solid {B1};
    border-bottom: none;
    padding: 7px 18px;
    border-radius: 6px 6px 0 0;
    font-size: 11px;
    margin-right: 2px;
}}
QTabBar::tab:selected {{
    background: {BG1};
    color: {ACC};
    border-bottom: 2px solid {ACC};
}}
QTabBar::tab:hover:!selected {{ color: {T2}; background: {BG3}; }}

/* ── GroupBox ── */
QGroupBox {{
    border: 1px solid {B1};
    border-radius: 8px;
    margin-top: 12px;
    padding-top: 10px;
    color: {T3};
    font-family: "{MONO}";
    font-size: 10px;
    letter-spacing: 0.8px;
    text-transform: uppercase;
}}
QGroupBox::title {{
    subcontrol-origin: margin;
    subcontrol-position: top left;
    padding: 0 8px;
    left: 12px;
    top: -1px;
}}

/* ── ProgressBar ── */
QProgressBar {{
    background: {BG4};
    border: none;
    border-radius: 4px;
    height: 6px;
    text-align: center;
}}
QProgressBar::chunk {{
    border-radius: 4px;
    background: {ACC};
}}

/* ── ComboBox ── */
QComboBox {{
    background: {BG3};
    color: {T1};
    border: 1px solid {B2};
    border-radius: 5px;
    padding: 5px 10px;
    font-family: "{MONO}";
    font-size: 11px;
}}
QComboBox:hover {{ border-color: {B3}; }}
QComboBox::drop-down {{ border: none; width: 24px; }}
QComboBox QAbstractItemView {{
    background: {BG3};
    color: {T1};
    border: 1px solid {B2};
    border-radius: 4px;
    selection-background-color: {rgba(ACC, 0.2)};
    outline: none;
}}

/* ── CheckBox ── */
QCheckBox {{
    color: {T1};
    spacing: 8px;
    font-size: 11px;
}}
QCheckBox::indicator {{
    width: 16px; height: 16px;
    border: 1px solid {B2};
    border-radius: 4px;
    background: {BG3};
}}
QCheckBox::indicator:checked {{
    background: {ACC2};
    border-color: {ACC};
}}
QCheckBox::indicator:hover {{ border-color: {B3}; }}

/* ── Splitter ── */
QSplitter::handle {{
    background: {B1};
    width: 1px;
    height: 1px;
}}

/* ── Tooltip ── */
QToolTip {{
    background: {BG3};
    color: {T1};
    border: 1px solid {B2};
    border-radius: 5px;
    padding: 5px 10px;
    font-family: "{MONO}";
    font-size: 11px;
}}

/* ── StatusBar ── */
QStatusBar {{
    background: {BG1};
    color: {T4};
    border-top: 1px solid {B1};
    font-family: "{MONO}";
    font-size: 10px;
}}
QStatusBar::item {{ border: none; }}

/* ── MenuBar ── */
QMenuBar {{
    background: {BG1};
    color: {T2};
    border-bottom: 1px solid {B1};
    padding: 2px 4px;
    font-size: 11px;
}}
QMenuBar::item {{ padding: 4px 10px; border-radius: 4px; }}
QMenuBar::item:selected {{ background: {BG3}; color: {T1}; }}

/* ── Menu ── */
QMenu {{
    background: {BG2};
    color: {T1};
    border: 1px solid {B2};
    border-radius: 6px;
    padding: 4px;
}}
QMenu::item {{ padding: 6px 24px 6px 12px; border-radius: 4px; }}
QMenu::item:selected {{ background: {rgba(ACC, 0.15)}; }}
QMenu::separator {{ background: {B1}; height: 1px; margin: 4px 8px; }}

/* ── SpinBox ── */
QSpinBox {{
    background: {BG3};
    color: {T1};
    border: 1px solid {B2};
    border-radius: 5px;
    padding: 5px 8px;
    font-family: "{MONO}";
    font-size: 11px;
}}
QSpinBox:focus {{ border-color: {ACC}; }}

/* ── Scroll Area ── */
QScrollArea {{ border: none; background: transparent; }}
QScrollArea > QWidget > QWidget {{ background: transparent; }}
"""
