"""
OmniFi Widget — Network Map
Renders a force-directed network topology graph using QPainter.

Nodes:
  • Gateway (router icon, center)
  • Devices (circle nodes, positioned radially)
  • Internet cloud (top)

Edges show connection status.
Node colour reflects device trust/status.
Click a node to select it (emits node_selected(mac)).

No external graph library required — pure QPainter.
"""
import math
import random
from typing  import Dict, List, Optional, Tuple
from PyQt6.QtWidgets import QWidget, QSizePolicy, QToolTip
from PyQt6.QtCore    import Qt, QPointF, QRectF, pyqtSignal, QTimer
from PyQt6.QtGui     import (
    QPainter, QPen, QColor, QBrush, QFont, QPainterPath, QCursor,
)
from ui.theme import BG1, BG2, BG4, B1, B2, T1, T2, T3, T4, ACC, GRN, YLW, RED, ORG, PUR, mf, sf


# ── Node types ────────────────────────────────────────────────────────────────
class NodeKind:
    GATEWAY  = "gateway"
    DEVICE   = "device"
    INTERNET = "internet"
    UNKNOWN  = "unknown"


# Colour per device status
STATUS_COLORS = {
    "trusted":  GRN,
    "unknown":  T2,
    "suspect":  YLW,
    "isolated": ORG,
    "blocked":  RED,
}


class _Node:
    __slots__ = ("id","kind","label","status","mac","ip",
                 "x","y","vx","vy","r","selected","_pinned")

    def __init__(self, nid: str, kind: str, label: str = "",
                 mac: str = "", ip: str = "", status: str = "unknown"):
        self.id       = nid
        self.kind     = kind
        self.label    = label
        self.status   = status
        self.mac      = mac
        self.ip       = ip
        self.x        = random.uniform(-100, 100)
        self.y        = random.uniform(-100, 100)
        self.vx       = 0.0
        self.vy       = 0.0
        self.r        = 22 if kind == NodeKind.GATEWAY else 16
        self.selected = False
        self._pinned  = (kind in (NodeKind.GATEWAY, NodeKind.INTERNET))


class NetworkMapWidget(QWidget):
    """
    Interactive network topology map.
    Automatically layouts devices radially around the gateway.

    Signals:
        node_selected(mac)  — emitted when a device node is clicked
    """
    node_selected = pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._nodes:  Dict[str, _Node] = {}
        self._edges:  List[Tuple[str,str]] = []
        self._drag:   Optional[str] = None
        self._offset: QPointF = QPointF(0, 0)

        self.setMinimumSize(300, 200)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.setStyleSheet(f"background:{BG1}; border:1px solid {B1}; border-radius:8px;")
        self.setMouseTracking(True)

        # Physics timer
        self._phys = QTimer(self)
        self._phys.timeout.connect(self._step_physics)
        self._phys.start(50)   # 20 Hz

        self._init_static_nodes()

    # ── Static nodes (always present) ─────────────────────────────────────────

    def _init_static_nodes(self):
        gw = _Node("gateway", NodeKind.GATEWAY, "Router", status="trusted")
        gw.x = 0; gw.y = 0
        self._nodes["gateway"] = gw

        inet = _Node("internet", NodeKind.INTERNET, "Internet")
        inet.x = 0; inet.y = -150
        self._nodes["internet"] = inet

        self._edges.append(("gateway","internet"))

    # ── Public API ────────────────────────────────────────────────────────────

    def set_gateway(self, ip: str = "", mac: str = ""):
        gw = self._nodes.get("gateway")
        if gw:
            gw.label = f"Router\n{ip}" if ip else "Router"
            gw.ip    = ip
            gw.mac   = mac

    def add_device(self, mac: str, ip: str = "",
                   hostname: str = "", status: str = "unknown"):
        mac_up = mac.upper()
        if mac_up not in self._nodes:
            label = hostname or ip or mac_up[:8]
            angle = len(self._nodes) * (2 * math.pi / 8)
            n = _Node(mac_up, NodeKind.DEVICE, label, mac_up, ip, status)
            r = 120
            n.x = r * math.cos(angle) + random.uniform(-10, 10)
            n.y = r * math.sin(angle) + random.uniform(-10, 10)
            self._nodes[mac_up] = n
            if ("gateway", mac_up) not in self._edges:
                self._edges.append(("gateway", mac_up))
        else:
            n = self._nodes[mac_up]
            n.ip     = ip or n.ip
            n.label  = hostname or ip or mac_up[:8]
            n.status = status
        self.update()

    def update_device_status(self, mac: str, status: str):
        n = self._nodes.get(mac.upper())
        if n:
            n.status = status
            self.update()

    def remove_device(self, mac: str):
        mac_up = mac.upper()
        self._nodes.pop(mac_up, None)
        self._edges = [(a,b) for a,b in self._edges
                       if a != mac_up and b != mac_up]
        self.update()

    def clear_devices(self):
        for mid in list(self._nodes.keys()):
            if mid not in ("gateway","internet"):
                del self._nodes[mid]
        self._edges = [e for e in self._edges
                       if e[0] in ("gateway","internet") and e[1] in ("gateway","internet")]
        self._edges.append(("gateway","internet"))
        self.update()

    def load_devices(self, devs: List[dict]):
        self.clear_devices()
        for d in devs:
            self.add_device(
                mac      = d.get("mac",""),
                ip       = d.get("ip",""),
                hostname = d.get("hostname","") or d.get("vendor",""),
                status   = d.get("status","unknown"),
            )

    # ── Physics ───────────────────────────────────────────────────────────────

    def _step_physics(self):
        nodes = list(self._nodes.values())
        for n in nodes:
            if n._pinned:
                continue
            n.vx *= 0.7; n.vy *= 0.7

            # Repulsion from other nodes
            for m in nodes:
                if m.id == n.id: continue
                dx = n.x - m.x; dy = n.y - m.y
                dist = math.hypot(dx, dy) or 0.01
                force = 2000 / (dist * dist)
                n.vx += (dx / dist) * force
                n.vy += (dy / dist) * force

            # Attraction to gateway
            gw = self._nodes.get("gateway")
            if gw and n.id != "gateway":
                dx = gw.x - n.x; dy = gw.y - n.y
                dist = math.hypot(dx, dy) or 0.01
                n.vx += (dx / dist) * min(dist * 0.02, 3)
                n.vy += (dy / dist) * min(dist * 0.02, 3)

            # Clamp velocity
            speed = math.hypot(n.vx, n.vy)
            if speed > 5:
                n.vx = n.vx / speed * 5
                n.vy = n.vy / speed * 5

            n.x += n.vx; n.y += n.vy

        self.update()

    # ── Paint ─────────────────────────────────────────────────────────────────

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)

        cx = self.width()  / 2 + self._offset.x()
        cy = self.height() / 2 + self._offset.y()

        def screen(n: _Node) -> QPointF:
            return QPointF(cx + n.x, cy + n.y)

        # Draw edges
        ep = QPen(QColor(B2), 1)
        ep.setStyle(Qt.PenStyle.DashLine)
        p.setPen(ep)
        for (a_id, b_id) in self._edges:
            a = self._nodes.get(a_id); b = self._nodes.get(b_id)
            if a and b:
                pa = screen(a); pb = screen(b)
                p.drawLine(pa.toPoint(), pb.toPoint())

        # Draw nodes
        for n in self._nodes.values():
            pos = screen(n)
            x, y, r = pos.x(), pos.y(), n.r

            # Node fill colour
            if n.kind == NodeKind.GATEWAY:
                fill = QColor(ACC)
            elif n.kind == NodeKind.INTERNET:
                fill = QColor(PUR)
            else:
                fill = QColor(STATUS_COLORS.get(n.status, T3))

            # Outer ring for selected / suspect
            if n.selected:
                sel_pen = QPen(QColor(ACC), 2)
                p.setPen(sel_pen)
                p.setBrush(Qt.BrushStyle.NoBrush)
                p.drawEllipse(QPointF(x, y), r + 5, r + 5)

            # Node circle
            c = QColor(fill); c.setAlpha(200)
            p.setBrush(QBrush(c))
            border_pen = QPen(QColor(fill).lighter(130), 1)
            p.setPen(border_pen)
            if n.kind == NodeKind.INTERNET:
                # Cloud shape (rounded rect)
                p.drawRoundedRect(QRectF(x-r, y-r*0.7, r*2, r*1.4), r*0.4, r*0.4)
            elif n.kind == NodeKind.GATEWAY:
                # Router — diamond
                path = QPainterPath()
                path.moveTo(x, y - r)
                path.lineTo(x + r, y)
                path.lineTo(x, y + r)
                path.lineTo(x - r, y)
                path.closeSubpath()
                p.fillPath(path, QBrush(c))
                p.drawPath(path)
            else:
                p.drawEllipse(QPointF(x, y), r, r)

            # Label
            p.setPen(QPen(QColor(T1)))
            p.setFont(mf(7))
            label_lines = n.label.split("\n")
            for i, line in enumerate(label_lines[:2]):
                ly = y + r + 10 + i * 12
                p.drawText(QRectF(x - 40, ly, 80, 12),
                           Qt.AlignmentFlag.AlignCenter, line[:12])

            # Status dot for devices
            if n.kind == NodeKind.DEVICE:
                dot_c = QColor(STATUS_COLORS.get(n.status, T3))
                p.setBrush(QBrush(dot_c))
                p.setPen(Qt.PenStyle.NoPen)
                p.drawEllipse(QPointF(x + r - 4, y - r + 4), 5, 5)

        p.end()

    # ── Interaction ───────────────────────────────────────────────────────────

    def _node_at(self, pos: QPointF) -> Optional[_Node]:
        cx = self.width()  / 2 + self._offset.x()
        cy = self.height() / 2 + self._offset.y()
        for n in self._nodes.values():
            dx = pos.x() - (cx + n.x)
            dy = pos.y() - (cy + n.y)
            if math.hypot(dx, dy) <= n.r + 6:
                return n
        return None

    def mousePressEvent(self, ev):
        pos = QPointF(ev.position())
        n   = self._node_at(pos)
        # Deselect all
        for node in self._nodes.values():
            node.selected = False
        if n:
            n.selected = True
            if n.kind == NodeKind.DEVICE:
                self.node_selected.emit(n.mac)
            self._drag = n.id
        self.update()

    def mouseMoveEvent(self, ev):
        pos  = QPointF(ev.position())
        n    = self._node_at(pos)
        if n:
            tip = f"{n.label}  |  {n.mac}  |  {n.ip}  |  {n.status.upper()}"
            QToolTip.showText(ev.globalPosition().toPoint(), tip, self)
        if self._drag and self._drag in self._nodes:
            node = self._nodes[self._drag]
            if not node._pinned:
                cx = self.width()  / 2 + self._offset.x()
                cy = self.height() / 2 + self._offset.y()
                node.x = pos.x() - cx
                node.y = pos.y() - cy
                self.update()

    def mouseReleaseEvent(self, _):
        self._drag = None

    def wheelEvent(self, ev):
        # Pan with scroll
        self._offset += QPointF(ev.angleDelta().x() * 0.3,
                                ev.angleDelta().y() * 0.3)
        self.update()
