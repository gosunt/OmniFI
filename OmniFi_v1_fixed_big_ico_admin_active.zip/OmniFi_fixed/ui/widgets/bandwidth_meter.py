"""
OmniFi — Bandwidth Meter Widget
==================================
A PyQt6 widget that shows real-time TX / RX speeds per device,
plus an aggregate network throughput bar.

Layout
──────
  ┌──────────────────────────────────────────────────┐
  │  📶 Network Bandwidth                   ↑ 1.2 MB/s  ↓ 4.5 MB/s │
  │  ─────────────────────────────────────────────── │
  │  192.168.1.10  (Samsung Galaxy)                                  │
  │     ↑  512 KB/s  ████████░░░░░░░░░░░░            │
  │     ↓  2.1 MB/s  ████████████████░░░░            │
  │  192.168.1.12  (MacBook Pro)                                     │
  │     ↑   64 KB/s  ██░░░░░░░░░░░░░░░░░░            │
  │     ↓  890 KB/s  ████████████░░░░░░░░            │
  └──────────────────────────────────────────────────┘

Feed it via  update_stats(stats_dict)  where stats_dict is:
  {
    "192.168.1.10": {
        "mac": "aa:bb:cc:dd:ee:ff",
        "hostname": "Samsung Galaxy",
        "rx_bps": 2100000,   # bytes per second
        "tx_bps": 512000,
        "rx_total": 104857600,
        "tx_total": 5242880,
        "signal_dbm": -62,
    },
    ...
  }

The backend (core/telemetry.py) already collects rx_bytes/tx_bytes.
Compute delta bps by comparing successive samples and call update_stats().
"""
from __future__ import annotations

from typing import Dict, Optional
from PyQt6.QtCore    import Qt, QTimer, pyqtSlot
from PyQt6.QtGui     import QColor, QFont, QPainter, QPen, QBrush, QLinearGradient
from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel,
                              QFrame, QScrollArea, QSizePolicy)


def _fmt_speed(bps: float) -> str:
    """Format bytes/sec → human readable."""
    if bps >= 1_048_576:
        return f"{bps / 1_048_576:.1f} MB/s"
    elif bps >= 1_024:
        return f"{bps / 1_024:.0f} KB/s"
    else:
        return f"{bps:.0f} B/s"


def _fmt_total(b: float) -> str:
    if b >= 1_073_741_824:
        return f"{b / 1_073_741_824:.2f} GB"
    elif b >= 1_048_576:
        return f"{b / 1_048_576:.1f} MB"
    elif b >= 1_024:
        return f"{b / 1_024:.0f} KB"
    return f"{b:.0f} B"


# ─────────────────────────────────────────────────────────────────────────────
class SpeedBar(QWidget):
    """A single horizontal speed bar (TX or RX)."""

    BAR_H = 10
    BAR_COLORS = {
        "rx": ("#00c8ff", "#0066cc"),   # blue gradient
        "tx": ("#00e676", "#007c41"),   # green gradient
    }

    def __init__(self, direction: str = "rx", parent=None):
        super().__init__(parent)
        self._dir = direction
        self._ratio = 0.0   # 0.0 – 1.0
        self.setFixedHeight(self.BAR_H + 2)
        self.setMinimumWidth(80)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)

    def set_ratio(self, ratio: float):
        self._ratio = max(0.0, min(1.0, ratio))
        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        w, h = self.width(), self.height()

        # Background
        p.setBrush(QBrush(QColor("#1e2533")))
        p.setPen(Qt.PenStyle.NoPen)
        p.drawRoundedRect(0, 1, w, h - 2, 4, 4)

        # Filled portion
        fill_w = max(4, int(w * self._ratio))
        c1, c2 = self.BAR_COLORS[self._dir]
        grad = QLinearGradient(0, 0, fill_w, 0)
        grad.setColorAt(0, QColor(c1))
        grad.setColorAt(1, QColor(c2))
        p.setBrush(QBrush(grad))
        p.drawRoundedRect(0, 1, fill_w, h - 2, 4, 4)
        p.end()


# ─────────────────────────────────────────────────────────────────────────────
class DeviceBandwidthRow(QFrame):
    """One device's TX + RX row."""

    def __init__(self, ip: str, parent=None):
        super().__init__(parent)
        self._ip = ip
        self._max_bps = 1.0   # scaling reference (updated globally)
        self._rx_bps = 0.0
        self._tx_bps = 0.0
        self.setFrameShape(QFrame.Shape.StyledPanel)
        self.setObjectName("DeviceBWRow")
        self.setStyleSheet("""
            #DeviceBWRow {
                background: #1a2030;
                border: 1px solid #2a3550;
                border-radius: 6px;
                margin: 2px 0px;
            }
        """)
        self._build_ui()

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(8, 6, 8, 6)
        root.setSpacing(3)

        # Header row
        hdr = QHBoxLayout()
        self._lbl_ip = QLabel(self._ip)
        self._lbl_ip.setStyleSheet("color:#a0b0d0; font-size:11px; font-weight:600;")
        self._lbl_host = QLabel("")
        self._lbl_host.setStyleSheet("color:#607090; font-size:10px;")
        self._lbl_signal = QLabel("")
        self._lbl_signal.setStyleSheet("color:#607090; font-size:10px;")
        hdr.addWidget(self._lbl_ip)
        hdr.addWidget(self._lbl_host)
        hdr.addStretch()
        hdr.addWidget(self._lbl_signal)
        root.addLayout(hdr)

        # RX row
        rx_row = QHBoxLayout()
        rx_lbl = QLabel("↓ RX")
        rx_lbl.setStyleSheet("color:#00c8ff; font-size:10px; min-width:40px;")
        self._lbl_rx = QLabel("0 B/s")
        self._lbl_rx.setStyleSheet("color:#00c8ff; font-size:10px; min-width:72px;")
        self._bar_rx = SpeedBar("rx")
        rx_row.addWidget(rx_lbl)
        rx_row.addWidget(self._lbl_rx)
        rx_row.addWidget(self._bar_rx, 1)
        root.addLayout(rx_row)

        # TX row
        tx_row = QHBoxLayout()
        tx_lbl = QLabel("↑ TX")
        tx_lbl.setStyleSheet("color:#00e676; font-size:10px; min-width:40px;")
        self._lbl_tx = QLabel("0 B/s")
        self._lbl_tx.setStyleSheet("color:#00e676; font-size:10px; min-width:72px;")
        self._bar_tx = SpeedBar("tx")
        tx_row.addWidget(tx_lbl)
        tx_row.addWidget(self._lbl_tx)
        tx_row.addWidget(self._bar_tx, 1)
        root.addLayout(tx_row)

    def refresh(self, info: dict, max_bps: float):
        self._rx_bps = info.get("rx_bps", 0.0)
        self._tx_bps = info.get("tx_bps", 0.0)
        host = info.get("hostname", "") or info.get("mac", "")
        sig  = info.get("signal_dbm")

        self._lbl_ip.setText(self._ip)
        self._lbl_host.setText(f"  {host}" if host else "")
        self._lbl_signal.setText(f"📶 {sig} dBm" if sig else "")
        self._lbl_rx.setText(_fmt_speed(self._rx_bps))
        self._lbl_tx.setText(_fmt_speed(self._tx_bps))

        ref = max(max_bps, 1.0)
        self._bar_rx.set_ratio(self._rx_bps / ref)
        self._bar_tx.set_ratio(self._tx_bps / ref)


# ─────────────────────────────────────────────────────────────────────────────
class BandwidthMeterWidget(QWidget):
    """
    Drop this widget into any panel.

    Usage:
        bw = BandwidthMeterWidget()
        # later, from a QThread worker:
        bw.update_stats({
            "192.168.1.10": {"mac":"..","hostname":"..","rx_bps":2e6,"tx_bps":3e5,"signal_dbm":-62},
        })
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self._rows: Dict[str, DeviceBandwidthRow] = {}
        self._stats: Dict[str, dict] = {}
        self._build_ui()

        # Auto-refresh every 2 s
        self._timer = QTimer(self)
        self._timer.setInterval(2000)
        self._timer.timeout.connect(self._refresh)
        self._timer.start()

    # ── Public ───────────────────────────────────────────────────────────────
    @pyqtSlot(dict)
    def update_stats(self, stats: Dict[str, dict]):
        """Called by worker thread (via signal) with fresh speed data."""
        self._stats = stats
        self._refresh()

    # ── UI ────────────────────────────────────────────────────────────────────
    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(4, 4, 4, 4)
        root.setSpacing(4)

        # Header
        hdr = QHBoxLayout()
        title = QLabel("📊  Live Bandwidth")
        title.setStyleSheet("color:#e0eaff; font-weight:700; font-size:12px;")
        self._lbl_total_rx = QLabel("↓ --")
        self._lbl_total_rx.setStyleSheet("color:#00c8ff; font-size:11px;")
        self._lbl_total_tx = QLabel("↑ --")
        self._lbl_total_tx.setStyleSheet("color:#00e676; font-size:11px;")
        hdr.addWidget(title)
        hdr.addStretch()
        hdr.addWidget(self._lbl_total_rx)
        hdr.addSpacing(10)
        hdr.addWidget(self._lbl_total_tx)
        root.addLayout(hdr)

        sep = QFrame(); sep.setFrameShape(QFrame.Shape.HLine)
        sep.setStyleSheet("color:#2a3550;")
        root.addWidget(sep)

        # Scroll area for device rows
        self._scroll = QScrollArea()
        self._scroll.setWidgetResizable(True)
        self._scroll.setFrameShape(QFrame.Shape.NoFrame)
        self._scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self._scroll.setStyleSheet("background: transparent;")
        self._container = QWidget()
        self._vbox = QVBoxLayout(self._container)
        self._vbox.setContentsMargins(0, 0, 0, 0)
        self._vbox.setSpacing(3)
        self._vbox.addStretch()
        self._scroll.setWidget(self._container)
        root.addWidget(self._scroll, 1)

        self._lbl_empty = QLabel("No devices detected — start a scan.")
        self._lbl_empty.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._lbl_empty.setStyleSheet("color:#607090; font-size:11px; padding:20px;")
        root.addWidget(self._lbl_empty)

    def _refresh(self):
        stats = self._stats
        if not stats:
            self._lbl_empty.show()
            return
        self._lbl_empty.hide()

        max_bps = max(
            (max(v.get("rx_bps", 0), v.get("tx_bps", 0)) for v in stats.values()),
            default=1.0)

        total_rx = sum(v.get("rx_bps", 0) for v in stats.values())
        total_tx = sum(v.get("tx_bps", 0) for v in stats.values())
        self._lbl_total_rx.setText(f"↓ {_fmt_speed(total_rx)}")
        self._lbl_total_tx.setText(f"↑ {_fmt_speed(total_tx)}")

        # Add missing rows
        for ip in stats:
            if ip not in self._rows:
                row = DeviceBandwidthRow(ip)
                self._rows[ip] = row
                # Insert before the trailing stretch
                self._vbox.insertWidget(self._vbox.count() - 1, row)

        # Remove stale rows
        for ip in list(self._rows):
            if ip not in stats:
                self._vbox.removeWidget(self._rows[ip])
                self._rows[ip].deleteLater()
                del self._rows[ip]

        # Update all rows
        for ip, row in self._rows.items():
            row.refresh(stats[ip], max_bps)


# ─────────────────────────────────────────────────────────────────────────────
# Bandwidth speed calculator (call from telemetry worker)
# ─────────────────────────────────────────────────────────────────────────────
class BandwidthCalculator:
    """
    Feed successive TelemetrySample dicts; get back bps per device.
    Call  compute(samples)  where samples is a list of the most recent
    telemetry rows grouped by MAC.
    """

    def __init__(self):
        self._prev: Dict[str, dict] = {}   # mac → {ts, rx, tx}

    def compute(self, samples: list) -> Dict[str, dict]:
        """
        samples: list of dicts with keys ts, mac, ip, rx_bytes, tx_bytes,
                 rssi, hostname (optional).
        Returns  {ip: {mac, hostname, rx_bps, tx_bps, signal_dbm, ...}}
        """
        result: Dict[str, dict] = {}
        import time as _time
        now = _time.time()

        for s in samples:
            mac = s.get("mac", "")
            ip  = s.get("ip", mac)
            rx  = s.get("rx_bytes", 0)
            tx  = s.get("tx_bytes", 0)
            ts  = s.get("ts", now)

            prev = self._prev.get(mac)
            rx_bps = tx_bps = 0.0
            if prev:
                dt = max(float(ts) - float(prev["ts"]), 0.1)
                rx_bps = max(0.0, (rx - prev["rx"]) / dt)
                tx_bps = max(0.0, (tx - prev["tx"]) / dt)

            self._prev[mac] = {"ts": ts, "rx": rx, "tx": tx}

            result[ip] = {
                "mac":        mac,
                "hostname":   s.get("hostname", ""),
                "rx_bps":     rx_bps,
                "tx_bps":     tx_bps,
                "rx_total":   rx,
                "tx_total":   tx,
                "signal_dbm": s.get("rssi"),
            }
        return result
