"""
OmniFi Widget — Live Trust Score Graph
Renders a rolling time-series chart of the trust score using QPainter.
No external charting library required.

Features:
  • Smooth anti-aliased polyline
  • Colour zones (safe=green, caution=yellow, critical=red)
  • Y-axis labels (0/25/50/75/100)
  • X-axis time labels (last N minutes)
  • Current score annotation
  • Animated: call add_point(score, ts) from any thread
"""
import datetime
import math
from collections import deque
from PyQt6.QtWidgets import QWidget, QSizePolicy
from PyQt6.QtCore    import Qt, QTimer, QRect, QPointF, QRectF
from PyQt6.QtGui     import (
    QPainter, QPen, QColor, QBrush, QLinearGradient,
    QPolygonF, QPainterPath, QFont,
)
from ui.theme import BG0, BG2, BG4, B1, GRN, YLW, RED, ACC, T2, T3, T4, mf


class TrustGraphWidget(QWidget):
    """
    Live rolling trust score graph.
    Call  add_point(score, ts_iso)  to push a new data point.
    The graph auto-refreshes at 2 Hz.
    """

    MAX_POINTS = 120    # 120 samples = 30 min at 15 s intervals

    # Zone colours
    ZONE_SAFE     = QColor(34,  211, 160, 25)    # green fill
    ZONE_CAUTION  = QColor(251, 191, 36,  25)    # yellow fill
    ZONE_CRITICAL = QColor(244, 63,  94,  30)    # red fill

    LINE_SAFE     = QColor(34,  211, 160)
    LINE_CAUTION  = QColor(251, 191, 36)
    LINE_CRITICAL = QColor(244, 63,  94)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._points: deque = deque(maxlen=self.MAX_POINTS)
        self.setMinimumSize(300, 120)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.setStyleSheet(f"background:{BG0}; border:1px solid {B1}; border-radius:6px;")

        # Refresh timer
        self._timer = QTimer(self)
        self._timer.timeout.connect(self.update)
        self._timer.start(500)

        # Seed with baseline
        self.add_point(100)

    # ── Public API ────────────────────────────────────────────────────────────

    def add_point(self, score: int, ts: str = "") -> None:
        if not ts:
            ts = datetime.datetime.now().isoformat()
        score = max(0, min(100, int(score)))
        self._points.append({"score": score, "ts": ts})
        self.update()

    def clear(self) -> None:
        self._points.clear()
        self.add_point(100)

    def load_history(self, history: list) -> None:
        """Load from telemetry history list [{ts, trust_score}, ...]."""
        self._points.clear()
        for h in history[-self.MAX_POINTS:]:
            self.add_point(h.get("trust_score", 100), h.get("ts",""))
        self.update()

    # ── Paint ─────────────────────────────────────────────────────────────────

    def paintEvent(self, _) -> None:
        if len(self._points) < 2:
            return
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)

        w = self.width(); h = self.height()
        PAD_L = 38; PAD_R = 14; PAD_T = 12; PAD_B = 26
        pw = w - PAD_L - PAD_R
        ph = h - PAD_T  - PAD_B

        def y_of(score: int) -> float:
            return PAD_T + ph - (score / 100.0) * ph

        def x_of(idx: int, total: int) -> float:
            return PAD_L + (idx / max(1, total - 1)) * pw

        pts = list(self._points)
        n   = len(pts)

        # ── Background zones ─────────────────────────────────────────────────
        # Critical zone (0–50)
        p.fillRect(QRectF(PAD_L, y_of(50),  pw, ph - (ph - ph * 0.5)),
                   self.ZONE_CRITICAL)
        # Caution zone (50–75)
        p.fillRect(QRectF(PAD_L, y_of(75),  pw, ph * 0.25),
                   self.ZONE_CAUTION)
        # Safe zone (75–100)
        p.fillRect(QRectF(PAD_L, y_of(100), pw, ph * 0.25),
                   self.ZONE_SAFE)

        # ── Horizontal grid lines ─────────────────────────────────────────────
        grid_pen = QPen(QColor(B1)); grid_pen.setWidth(1)
        p.setPen(grid_pen)
        for score_mark in (0, 25, 50, 75, 100):
            y = y_of(score_mark)
            p.drawLine(int(PAD_L), int(y), int(PAD_L + pw), int(y))
            # Y-axis label
            p.setPen(QPen(QColor(T4)))
            p.setFont(mf(8))
            p.drawText(QRectF(0, y - 8, PAD_L - 4, 16),
                       Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter,
                       str(score_mark))
            p.setPen(grid_pen)

        # ── Score line ────────────────────────────────────────────────────────
        path = QPainterPath()
        path.moveTo(QPointF(x_of(0, n), y_of(pts[0]["score"])))
        for i in range(1, n):
            path.lineTo(QPointF(x_of(i, n), y_of(pts[i]["score"])))

        # Choose line colour based on last score
        last_score = pts[-1]["score"]
        if last_score >= 75:
            line_c = self.LINE_SAFE
        elif last_score >= 50:
            line_c = self.LINE_CAUTION
        else:
            line_c = self.LINE_CRITICAL

        line_pen = QPen(QColor(line_c), 2)
        line_pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        line_pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
        p.setPen(line_pen)
        p.drawPath(path)

        # ── Fill under line ───────────────────────────────────────────────────
        fill_path = QPainterPath(path)
        fill_path.lineTo(QPointF(x_of(n-1, n), PAD_T + ph))
        fill_path.lineTo(QPointF(x_of(0, n),   PAD_T + ph))
        fill_path.closeSubpath()
        grad = QLinearGradient(0, PAD_T, 0, PAD_T + ph)
        c = QColor(line_c); c.setAlpha(60)
        grad.setColorAt(0.0, c)
        c2 = QColor(line_c); c2.setAlpha(0)
        grad.setColorAt(1.0, c2)
        p.fillPath(fill_path, QBrush(grad))

        # ── Current score dot + label ─────────────────────────────────────────
        lx = x_of(n-1, n); ly = y_of(last_score)
        dot_pen = QPen(QColor(line_c), 2)
        p.setPen(dot_pen)
        p.setBrush(QBrush(QColor(line_c)))
        p.drawEllipse(QPointF(lx, ly), 4, 4)
        p.setBrush(Qt.BrushStyle.NoBrush)

        # Score annotation
        p.setFont(mf(10, bold=True))
        p.setPen(QPen(QColor(line_c)))
        score_text = str(last_score)
        text_x = min(lx + 6, w - 36)
        p.drawText(QRectF(text_x, ly - 10, 32, 18),
                   Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
                   score_text)

        # ── X-axis time labels ────────────────────────────────────────────────
        p.setFont(mf(8))
        p.setPen(QPen(QColor(T4)))
        if n >= 2:
            # First timestamp
            try:
                t0 = datetime.datetime.fromisoformat(pts[0]["ts"])
                t0_str = t0.strftime("%H:%M")
                p.drawText(QRectF(PAD_L - 12, h - PAD_B + 4, 36, 14),
                           Qt.AlignmentFlag.AlignCenter, t0_str)
            except Exception:
                pass
            # Last timestamp
            try:
                tN = datetime.datetime.fromisoformat(pts[-1]["ts"])
                tN_str = tN.strftime("%H:%M")
                p.drawText(QRectF(PAD_L + pw - 24, h - PAD_B + 4, 36, 14),
                           Qt.AlignmentFlag.AlignCenter, tN_str)
            except Exception:
                pass

        p.end()
