"""
OmniFi Widget — Alert Item
Single alert card rendered in the Live Feed.
Shows: severity bar · level pill · source · message · detail ·
       correlation chain (if any) · spike badge (if any) ·
       action buttons (admin mode) or advisory text (client mode).
"""
import re
from PyQt6.QtWidgets import (
    QFrame, QHBoxLayout, QVBoxLayout, QLabel, QPushButton,
)
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui  import QColor
from ui.theme     import (
    LVL_C, BG2, BG3, B1, B2, T1, T2, T3, T4, YLW, PUR, ACC, RED,
    rgba, mf, sf,
)


class AlertItem(QFrame):
    """
    A single alert card.
    Emits action_sig(action_name, alert_dict) when an action button is clicked.
    """
    action_sig = pyqtSignal(str, dict)

    def __init__(self, alert: dict, is_admin: bool, safe_mode: bool, parent=None):
        super().__init__(parent)
        self._alert    = alert
        self._is_admin = is_admin
        self._safe     = safe_mode
        self._build()

    # ── build ─────────────────────────────────────────────────────────────────
    def _build(self):
        lvl = self._alert.get("level", "low")
        lc  = LVL_C.get(lvl, T2)

        self.setObjectName("AlertItem")
        self.setStyleSheet(f"""
            #AlertItem {{
                background: {BG2};
                border: 1px solid {B1};
                border-radius: 8px;
                margin-bottom: 4px;
            }}
            #AlertItem:hover {{ border-color: {B2}; }}
        """)

        outer = QHBoxLayout(self)
        outer.setContentsMargins(0, 0, 10, 0)
        outer.setSpacing(0)

        # ── left severity bar ─────────────────────────────────────────────────
        bar = QFrame()
        bar.setFixedWidth(4)
        bar.setStyleSheet(
            f"background: {lc}; border-radius: 4px 0 0 4px;")
        outer.addWidget(bar)

        # ── main body ─────────────────────────────────────────────────────────
        body = QVBoxLayout()
        body.setContentsMargins(12, 9, 6, 9)
        body.setSpacing(5)

        # Header row: pill | source | [corr badge] | [spike badge] | timestamp
        hr = QHBoxLayout(); hr.setSpacing(6)
        r, g, b = QColor(lc).red(), QColor(lc).green(), QColor(lc).blue()

        pill = QLabel(lvl.upper()); pill.setFont(mf(8, bold=True))
        pill.setStyleSheet(
            f"color:{lc}; background:rgba({r},{g},{b},0.18);"
            f"border:1px solid rgba({r},{g},{b},0.4);"
            f"border-radius:3px; padding:1px 7px;")
        hr.addWidget(pill)

        src = QLabel(self._alert.get("source", "")); src.setFont(mf(8))
        src.setStyleSheet(
            f"color:{T3}; background:{BG3};"
            f"border:1px solid {B1}; border-radius:3px; padding:1px 6px;")
        hr.addWidget(src)

        # Correlation badge
        if self._alert.get("corr_data"):
            cd = self._alert["corr_data"]
            cl = QLabel(f"⚡ {cd.get('conf',0)}% conf"); cl.setFont(mf(8, bold=True))
            cl.setStyleSheet(
                f"color:{PUR}; background:{rgba(PUR,0.12)};"
                f"border:1px solid {rgba(PUR,0.35)};"
                f"border-radius:3px; padding:1px 6px;")
            hr.addWidget(cl)

        # Spike badge
        if self._alert.get("spike_data"):
            sp = self._alert["spike_data"]
            sl = QLabel(f"📈 {sp.get('rate',0)}/60 s"); sl.setFont(mf(8))
            sl.setStyleSheet(
                f"color:{YLW}; background:{rgba(YLW,0.10)};"
                f"border:1px solid {rgba(YLW,0.3)};"
                f"border-radius:3px; padding:1px 5px;")
            hr.addWidget(sl)

        hr.addStretch()
        ts = self._alert.get("ts", "")[:19].replace("T", " ")
        tl = QLabel(ts); tl.setFont(mf(8))
        tl.setStyleSheet(f"color:{T4};")
        hr.addWidget(tl)
        body.addLayout(hr)

        # Message
        ml = QLabel(self._alert.get("message", ""))
        ml.setFont(sf(11))
        ml.setStyleSheet(f"color:{T1};")
        ml.setWordWrap(True)
        body.addWidget(ml)

        # Detail (monospace code-style)
        det = self._alert.get("detail", "")
        if det:
            dl = QLabel(det); dl.setFont(mf(9))
            dl.setStyleSheet(
                f"color:{T2}; background:{BG3};"
                f"border-radius:4px; padding:4px 8px;")
            dl.setWordWrap(True)
            body.addWidget(dl)

        # Correlation signal chain
        if self._alert.get("corr_data"):
            cd   = self._alert["corr_data"]
            sigs = " + ".join(cd.get("signals", []))
            sc   = QLabel(f"Signals: {sigs}  →  {cd.get('result','')}")
            sc.setFont(mf(9))
            sc.setStyleSheet(
                f"color:{PUR}; background:{rgba(PUR,0.06)};"
                f"border:1px solid {rgba(PUR,0.18)};"
                f"border-radius:4px; padding:3px 8px;")
            body.addWidget(sc)

        # ── Action row ────────────────────────────────────────────────────────
        actions = self._alert.get("actions", [])
        if actions:
            ar = QHBoxLayout(); ar.setSpacing(5)

            if self._is_admin:
                _CLS = {
                    "block":           "danger",
                    "quarantine":      "danger",
                    "isolate":         "warn",
                    "whitelist":       "success",
                    "exception":       "warn",
                    "vpn":             "purple",
                    "change_password": "warn",
                    "investigate":     "ghost",
                    "ignore":          "ghost",
                }
                for action in actions:
                    b = QPushButton(action.replace("_", " ").title())
                    b.setFont(mf(9)); b.setFixedHeight(24)
                    cls = _CLS.get(action, "ghost")
                    b.setProperty("cls", cls)
                    b.clicked.connect(
                        lambda _, a=action: self.action_sig.emit(a, self._alert))
                    ar.addWidget(b)

                if self._safe and any(
                    a in actions for a in
                    ("block","quarantine","isolate","whitelist","exception")
                ):
                    sl3 = QLabel("🛡 Safe mode — confirm required")
                    sl3.setFont(mf(8))
                    sl3.setStyleSheet(f"color:{YLW};")
                    ar.addWidget(sl3)
            else:
                # Client mode: advisory only, zero enforcement buttons
                adv = QLabel(
                    "💡 Use a VPN · Avoid sensitive tasks · "
                    "Switch to mobile data if this network is compromised.")
                adv.setFont(mf(9)); adv.setWordWrap(True)
                adv.setStyleSheet(
                    f"color:{ACC}; background:{rgba(ACC,0.06)};"
                    f"border:1px solid {rgba(ACC,0.2)};"
                    f"border-radius:4px; padding:3px 8px;")
                ar.addWidget(adv)

            ar.addStretch()
            body.addLayout(ar)

        outer.addLayout(body)
