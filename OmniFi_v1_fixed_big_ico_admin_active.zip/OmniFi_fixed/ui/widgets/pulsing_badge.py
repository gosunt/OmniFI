"""
OmniFi Widget — Pulsing Badge & Status Dot
PulsingBadge  : animated red count badge (alert counts)
StatusDot     : small coloured dot with optional pulse (module health)
ModuleChip    : inline name + dot chip for monitor bar
"""
from PyQt6.QtWidgets import QLabel, QHBoxLayout, QWidget
from PyQt6.QtCore    import QTimer, Qt
from PyQt6.QtGui     import QFont
from ui.theme        import BG4, T4, GRN, YLW, RED, T3, rgba, mf


class PulsingBadge(QLabel):
    """
    Animated count badge. Pulses red when count > 0.
    call set_count(n) to update.
    """
    def __init__(self, parent=None):
        super().__init__("0", parent)
        self._n      = 0
        self._bright = True
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setMinimumWidth(30)
        self.setFixedHeight(20)
        self.setFont(mf(9, bold=True))

        self._timer = QTimer(self)
        self._timer.timeout.connect(self._pulse)
        self._timer.start(850)
        self._repaint()

    def set_count(self, n: int) -> None:
        self._n = n
        self.setText(str(n))
        self._repaint()
        if n > 0 and not self._timer.isActive():
            self._timer.start(850)
        elif n == 0:
            self._timer.stop()
            self._bright = True
            self._repaint()

    def _pulse(self):
        self._bright = not self._bright
        self._repaint()

    def _repaint(self):
        if self._n == 0:
            self.setStyleSheet(
                f"background:{BG4}; color:{T4}; "
                f"border-radius:10px; padding:0 6px;")
        else:
            a = "ff" if self._bright else "77"
            self.setStyleSheet(
                f"background:#{a}f43f5e; color:#fff; "
                f"border-radius:10px; padding:0 6px;")


class StatusDot(QLabel):
    """
    Small coloured status indicator circle.
    status: "active" | "warn" | "off" | "error"
    """
    STATUS_COLORS = {
        "active": GRN,
        "warn":   YLW,
        "off":    T3,
        "error":  RED,
    }

    def __init__(self, status: str = "active", pulse: bool = False, parent=None):
        super().__init__("●", parent)
        self._status = status
        self._bright = True
        self.setFont(mf(9))
        self._repaint()

        if pulse:
            t = QTimer(self)
            t.timeout.connect(self._tick)
            t.start(1100)

    def set_status(self, status: str) -> None:
        self._status = status
        self._repaint()

    def _tick(self):
        self._bright = not self._bright
        self._repaint()

    def _repaint(self):
        c = self.STATUS_COLORS.get(self._status, T3)
        if not self._bright:
            c = T3
        self.setStyleSheet(f"color:{c}; background:transparent;")


class ModuleChip(QWidget):
    """
    Compact `● ModuleName  STATUS` chip for the monitor status bar.
    """
    def __init__(self, name: str, status: str = "active", parent=None):
        super().__init__(parent)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(4, 0, 8, 0)
        lay.setSpacing(4)

        self._dot  = StatusDot(status, pulse=(status=="warn"))
        self._name = QLabel(name)
        self._name.setFont(mf(8))
        self._name.setStyleSheet(f"color:{T3};")

        lay.addWidget(self._dot)
        lay.addWidget(self._name)

    def set_status(self, status: str) -> None:
        self._dot.set_status(status)
        c = StatusDot.STATUS_COLORS.get(status, T3)
        self._name.setStyleSheet(f"color:{c};")
