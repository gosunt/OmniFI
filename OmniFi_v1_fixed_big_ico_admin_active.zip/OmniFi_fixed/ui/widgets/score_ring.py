"""
OmniFi Widget — Score Ring
Circular arc gauge drawn with QPainter.
Used on: Dashboard, Network Cards, Sidebar mini-ring.
"""
from PyQt6.QtWidgets import QWidget
from PyQt6.QtCore    import Qt, QRect, QPropertyAnimation, QEasingCurve, pyqtProperty
from PyQt6.QtGui     import QPainter, QColor, QPen, QFont
from ui.theme        import VDT_C, T2, BG4, mf


class ScoreRing(QWidget):
    """
    Animatable circular score ring.
    set_score(value, verdict) smoothly animates to the new value.
    """

    def __init__(self, size: int = 80, thickness: int = 7, parent=None):
        super().__init__(parent)
        self._size      = size
        self._thickness = thickness
        self._score     = 0
        self._target    = 0
        self._verdict   = "caution"
        self.setFixedSize(size, size)

        # Animation
        self._anim = QPropertyAnimation(self, b"_anim_score", self)
        self._anim.setDuration(600)
        self._anim.setEasingCurve(QEasingCurve.Type.OutCubic)

    # ── animated property ─────────────────────────────────────────────────────
    def _get_anim_score(self):
        return self._score

    def _set_anim_score(self, v):
        self._score = v
        self.update()

    _anim_score = pyqtProperty(int, _get_anim_score, _set_anim_score)

    # ── public API ────────────────────────────────────────────────────────────
    def set_score(self, score: int, verdict: str = "caution") -> None:
        self._verdict = verdict
        self._target  = max(0, min(100, score))
        self._anim.stop()
        self._anim.setStartValue(self._score)
        self._anim.setEndValue(self._target)
        self._anim.start()

    def set_score_instant(self, score: int, verdict: str = "caution") -> None:
        """No animation — use for rapid refresh."""
        self._verdict = verdict
        self._score   = max(0, min(100, score))
        self.update()

    # ── paint ─────────────────────────────────────────────────────────────────
    def paintEvent(self, _) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)

        sz  = self._size
        m   = self._thickness + 2
        r   = QRect(m, m, sz - 2*m, sz - 2*m)
        col = QColor(VDT_C.get(self._verdict, T2))

        # Background track
        bg_pen = QPen(QColor(BG4), self._thickness)
        bg_pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        p.setPen(bg_pen)
        p.drawArc(r, 0, 360 * 16)

        # Score arc (from 12 o'clock, clockwise)
        if self._score > 0:
            fg_pen = QPen(col, self._thickness)
            fg_pen.setCapStyle(Qt.PenCapStyle.RoundCap)
            p.setPen(fg_pen)
            span   = int((self._score / 100) * 360 * 16)
            p.drawArc(r, 90 * 16, -span)

        # Centre text — score value
        p.setPen(QPen(col))
        p.setFont(mf(int(sz * 0.22), bold=True))
        p.drawText(r, Qt.AlignmentFlag.AlignCenter, str(self._score))
        p.end()
