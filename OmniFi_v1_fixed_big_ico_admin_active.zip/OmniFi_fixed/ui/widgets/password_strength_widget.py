"""
OmniFi — Password Strength Checker for Scanned Networks
=========================================================
A focused sub-widget for the Scanner Panel that shows, for every
discovered network that has a saved password:
  • Password strength score (entropy / complexity / policy)
  • Colour-coded badge (Critical / Weak / Fair / Strong / Excellent)
  • One-click "Change password" shortcut (admin mode only — opens
    the router's wireless-password page via the sitemap)
  • Policy violations listed inline

Integrates with  core.backend.score_password()  and
                  core.backend.read_saved_passwords().
"""
from __future__ import annotations

from typing import Callable, List, Optional

from PyQt6.QtCore    import Qt, QTimer, pyqtSlot
from PyQt6.QtGui     import QColor, QFont
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QFrame, QScrollArea, QSizePolicy, QToolTip,
)

# ── Score → badge ─────────────────────────────────────────────────────────────
def _score_badge(score: int) -> tuple:
    """Return (label, fg_color, bg_color)."""
    if score >= 90:
        return "Excellent", "#00e676", "#002211"
    if score >= 70:
        return "Strong",    "#76ff03", "#1a2600"
    if score >= 50:
        return "Fair",      "#ffeb3b", "#2a2000"
    if score >= 30:
        return "Weak",      "#ff9800", "#2a1000"
    return "Critical", "#f44336", "#2a0000"


def _bar_color(score: int) -> str:
    if score >= 70:
        return "#00c853"
    if score >= 50:
        return "#ffeb3b"
    if score >= 30:
        return "#ff9800"
    return "#f44336"


# ─────────────────────────────────────────────────────────────────────────────
class PasswordStrengthRow(QFrame):
    """One row per scanned network that has a saved password."""

    change_requested = None   # will be set by parent to a Callable

    def __init__(self, ssid: str, password: str,
                 score_fn: Callable[[str], dict],
                 is_admin_fn: Callable[[], bool],
                 change_fn: Optional[Callable[[str], None]] = None,
                 parent=None):
        super().__init__(parent)
        self._ssid = ssid
        self._score_fn = score_fn
        self._is_admin_fn = is_admin_fn
        self._change_fn = change_fn
        self.setFrameShape(QFrame.Shape.StyledPanel)
        self.setObjectName("PwRow")
        self.setStyleSheet("""
            #PwRow {
                background:#14192a;
                border:1px solid #2a3550;
                border-radius:6px;
                margin:2px 0;
            }
        """)
        self._build(password)

    def _build(self, password: str):
        try:
            result = self._score_fn(password)
        except Exception:
            result = {"score": 0, "issues": ["Unable to score password"], "entropy": 0}

        score  = result.get("score", 0)
        issues = result.get("issues", [])
        entropy= result.get("entropy", 0)
        label, fg, bg = _score_badge(score)

        root = QVBoxLayout(self)
        root.setContentsMargins(10, 7, 10, 7)
        root.setSpacing(4)

        # Row 1: SSID  +  badge
        r1 = QHBoxLayout()
        lbl_ssid = QLabel(f"📶  {self._ssid}")
        lbl_ssid.setStyleSheet("color:#c0d0f0; font-weight:600; font-size:12px;")
        lbl_badge = QLabel(f"  {label}  ")
        lbl_badge.setStyleSheet(
            f"color:{fg}; background:{bg}; border:1px solid {fg}; "
            f"border-radius:4px; font-size:10px; padding:1px 6px; font-weight:700;")
        lbl_entropy = QLabel(f"Entropy: {entropy:.0f} bit")
        lbl_entropy.setStyleSheet("color:#607090; font-size:10px;")
        r1.addWidget(lbl_ssid)
        r1.addStretch()
        lbl_entropy.setAlignment(Qt.AlignmentFlag.AlignRight)
        r1.addWidget(lbl_entropy)
        r1.addSpacing(8)
        r1.addWidget(lbl_badge)
        root.addLayout(r1)

        # Row 2: progress bar
        bar_outer = QFrame()
        bar_outer.setFixedHeight(6)
        bar_outer.setStyleSheet(
            "background:#1e2840; border-radius:3px;")
        bar_inner = QFrame(bar_outer)
        bar_inner.setFixedHeight(6)
        fill = int((score / 100) * max(bar_outer.width(), 200))
        bar_inner.setFixedWidth(fill)
        bar_inner.setStyleSheet(
            f"background:{_bar_color(score)}; border-radius:3px;")
        # We resize dynamically
        bar_outer._score = score
        bar_outer._bar_inner = bar_inner
        root.addWidget(bar_outer)

        # Row 3: issues + change button
        r3 = QHBoxLayout()
        if issues:
            issues_txt = "  ·  ".join(issues[:3])
            lbl_issues = QLabel(f"⚠  {issues_txt}")
            lbl_issues.setStyleSheet("color:#ff9800; font-size:9px;")
            lbl_issues.setWordWrap(True)
            r3.addWidget(lbl_issues, 1)
        else:
            lbl_ok = QLabel("✔  Password meets all policy requirements.")
            lbl_ok.setStyleSheet("color:#00c853; font-size:9px;")
            r3.addWidget(lbl_ok, 1)

        if self._change_fn and self._is_admin_fn():
            btn = QPushButton("🔑 Change Password")
            btn.setFixedHeight(22)
            btn.setStyleSheet(
                "background:#1e3050; color:#80aaff; border:1px solid #2a4070; "
                "border-radius:4px; font-size:9px; padding:0 8px;")
            btn.clicked.connect(lambda: self._change_fn(self._ssid))
            r3.addWidget(btn)
        root.addLayout(r3)

    def resizeEvent(self, ev):
        # Dynamically fill the bar to match widget width
        for child in self.findChildren(QFrame):
            if hasattr(child, "_score"):
                score = child._score
                bar_inner = child._bar_inner
                w = child.width()
                bar_inner.setFixedWidth(int((score / 100) * w))
        super().resizeEvent(ev)


# ─────────────────────────────────────────────────────────────────────────────
class PasswordStrengthWidget(QWidget):
    """
    Embed this in the Scanner Panel (or its own panel tab).

    Call  update_networks(networks)  where networks is a list of dicts
    from scan_wifi() — each dict may have "password" (plain) from
    read_saved_passwords() matching.
    """

    def __init__(self,
                 score_fn: Callable[[str], dict],
                 is_admin_fn: Callable[[], bool],
                 change_fn: Optional[Callable[[str], None]] = None,
                 parent=None):
        super().__init__(parent)
        self._score_fn = score_fn
        self._is_admin_fn = is_admin_fn
        self._change_fn = change_fn
        self._build_ui()

    # ── Public ───────────────────────────────────────────────────────────────
    @pyqtSlot(list)
    def update_networks(self, networks: list):
        """networks = list of dicts with 'ssid' and optionally 'password'."""
        # Clear old rows
        while self._rows_vbox.count() > 1:
            item = self._rows_vbox.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        has_any = False
        for net in networks:
            pwd = net.get("password") or net.get("saved_password") or ""
            if not pwd:
                continue
            has_any = True
            row = PasswordStrengthRow(
                ssid=net.get("ssid", "Unknown"),
                password=pwd,
                score_fn=self._score_fn,
                is_admin_fn=self._is_admin_fn,
                change_fn=self._change_fn,
            )
            self._rows_vbox.insertWidget(self._rows_vbox.count() - 1, row)

        self._lbl_empty.setVisible(not has_any)

    # ── UI ────────────────────────────────────────────────────────────────────
    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(4, 4, 4, 4)
        root.setSpacing(4)

        # Header
        hdr = QHBoxLayout()
        title = QLabel("🔐  Saved Password Strength — Scanned Networks")
        title.setStyleSheet("color:#e0eaff; font-weight:700; font-size:12px;")
        hdr.addWidget(title)
        hdr.addStretch()
        root.addLayout(hdr)

        policy_note = QLabel(
            "Policy: min 12 chars · uppercase + lowercase · digit · symbol · not a dictionary word")
        policy_note.setStyleSheet(
            "color:#607090; font-size:9px; background:#101520; "
            "border-radius:4px; padding:4px 8px; border:1px solid #1e2840;")
        root.addWidget(policy_note)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setStyleSheet("background:transparent;")

        container = QWidget()
        self._rows_vbox = QVBoxLayout(container)
        self._rows_vbox.setContentsMargins(0, 0, 0, 0)
        self._rows_vbox.setSpacing(3)
        self._rows_vbox.addStretch()
        scroll.setWidget(container)
        root.addWidget(scroll, 1)

        self._lbl_empty = QLabel(
            "No saved passwords found for scanned networks.\n"
            "Run a scan and ensure Wi-Fi passwords are saved on this device.")
        self._lbl_empty.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._lbl_empty.setWordWrap(True)
        self._lbl_empty.setStyleSheet("color:#607090; font-size:11px; padding:20px;")
        root.addWidget(self._lbl_empty)
