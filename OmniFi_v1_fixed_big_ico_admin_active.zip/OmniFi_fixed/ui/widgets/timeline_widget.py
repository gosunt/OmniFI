"""
OmniFi Widget — Attack Timeline
Renders a vertical event timeline using QPainter.
Each event shows:  ●  HH:MM:SS  [LEVEL]  message

Colour-coded by severity. Newest events at top.
"""
import datetime
from typing import List
from PyQt6.QtWidgets import QWidget, QVBoxLayout, QScrollArea, QFrame, QLabel
from PyQt6.QtCore    import Qt, QRect, QRectF
from PyQt6.QtGui     import QPainter, QPen, QColor, QBrush, QFont
from ui.theme        import BG0, BG2, BG3, BG4, B1, T1, T2, T3, T4, LVL_C, mf, sf, rgba


class TimelineWidget(QScrollArea):
    """
    Scrollable vertical attack timeline.
    Call  add_event(level, source, message, ts)  to add an entry.
    """

    MAX_EVENTS = 500

    def __init__(self, parent=None):
        super().__init__(parent)
        self._events: List[dict] = []
        self.setWidgetResizable(True)
        self.setFrameShape(QFrame.Shape.NoFrame)
        self.setStyleSheet(f"background:{BG0};")

        self._inner = QWidget()
        self._inner.setStyleSheet(f"background:{BG0};")
        self._layout = QVBoxLayout(self._inner)
        self._layout.setContentsMargins(0, 6, 0, 6)
        self._layout.setSpacing(0)
        self._layout.addStretch()
        self.setWidget(self._inner)

    # ── Public API ────────────────────────────────────────────────────────────

    def add_event(self, level: str, source: str,
                  message: str, ts: str = "") -> None:
        if not ts:
            ts = datetime.datetime.now().isoformat()
        event = {"level": level, "source": source, "message": message, "ts": ts}
        self._events.insert(0, event)
        if len(self._events) > self.MAX_EVENTS:
            self._events = self._events[:self.MAX_EVENTS]
        self._prepend_card(event)

    def clear(self) -> None:
        self._events.clear()
        while self._layout.count() > 1:
            item = self._layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

    def load(self, events: List[dict]) -> None:
        self.clear()
        for e in reversed(events):
            self.add_event(
                e.get("level","low"), e.get("source",""),
                e.get("message",""),  e.get("ts",""))

    # ── Card builder ──────────────────────────────────────────────────────────

    def _prepend_card(self, event: dict):
        card = _TimelineCard(event)
        self._layout.insertWidget(0, card)

    # ── Rendering ─────────────────────────────────────────────────────────────
    # (Handled per-card via _TimelineCard)


class _TimelineCard(QFrame):
    """One timeline entry card."""

    def __init__(self, event: dict, parent=None):
        super().__init__(parent)
        level   = event.get("level",  "low")
        source  = event.get("source", "")
        message = event.get("message","")
        ts      = event.get("ts","")[:19].replace("T"," ")

        lc = LVL_C.get(level, T3)
        self.setFixedHeight(40)
        self.setStyleSheet(f"background:transparent;")

        lay = QVBoxLayout(self)
        lay.setContentsMargins(48, 4, 12, 4)
        lay.setSpacing(0)

        # Message row
        rr = QLabel(f"{message}")
        rr.setFont(sf(9))
        rr.setStyleSheet(f"color:{T1};")
        rr.setWordWrap(False)

        # Meta row
        mr = QLabel(f"{ts}  ·  {source}")
        mr.setFont(mf(8))
        mr.setStyleSheet(f"color:{T4};")

        lay.addWidget(rr)
        lay.addWidget(mr)

        # Remember color for paint
        self._lc = lc

    def paintEvent(self, _):
        super().paintEvent(_)
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)

        # Vertical line
        lc = QColor(self._lc)
        pen = QPen(lc, 2)
        p.setPen(pen)
        p.drawLine(24, 0, 24, self.height())

        # Circle dot
        dot = QColor(lc)
        p.setBrush(QBrush(dot))
        p.setPen(QPen(QColor(BG0), 2))
        p.drawEllipse(18, self.height() // 2 - 5, 10, 10)
        p.end()
