"""
OmniFi Widget — Network Card
Displays one Wi-Fi AP's pre-join security score.

If the network dict contains pwd_found=True, also shows a password
strength bar inline on the card — no separate panel needed.

Password data injected by ScannerPanel after OS profile lookup:
    net["pwd_found"]   : bool
    net["pwd_score"]   : int  0-100
    net["pwd_issues"]  : list[str]
    net["pwd_entropy"] : float  bits
    net["pwd_masked"]  : str    e.g. "My**rd"

Click the card to expand the 8-vector breakdown grid.
"""
from PyQt6.QtWidgets import (
    QFrame, QHBoxLayout, QVBoxLayout, QLabel, QProgressBar,
    QGridLayout, QWidget,
)
from PyQt6.QtCore  import Qt, pyqtSignal
from PyQt6.QtGui   import QColor, QCursor, QFont
from ui.theme      import (
    VDT_C, BG2, BG3, BG4, B1, B2, T1, T2, T3, T4,
    RED, GRN, YLW, ORG, ACC,
    rgba, mf, sf,
)
from ui.widgets.score_ring import ScoreRing


class NetworkCard(QFrame):
    """
    Clickable network card.
    selected(net_dict) emitted on click.
    """
    selected = pyqtSignal(dict)

    def __init__(self, net: dict, rank: int, parent=None):
        super().__init__(parent)
        self._net      = net
        self._rank     = rank
        self._expanded = False
        self.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        self._build()

    # ─────────────────────────────────────────────────────────────────────────
    def _build(self):
        score   = self._net.get("score",    0)
        verdict = self._net.get("verdict",  "avoid")
        color   = self._net.get("color",    T2)
        evil    = bool(self._net.get("evil"))
        ssid    = self._net.get("ssid",     "") or "(hidden SSID)"
        bssid   = self._net.get("bssid",    "")
        proto   = self._net.get("proto",    "?")
        sig     = self._net.get("sig",      -90)
        freq    = self._net.get("freq",     2437)
        pmf     = self._net.get("pmf",      False)
        wps     = self._net.get("wps",      False)
        chan    = self._net.get("channel",  0)
        isp     = self._net.get("isp_name","")
        vecs    = self._net.get("vectors",  {})

        # Password data (may or may not be present)
        pwd_found   = self._net.get("pwd_found",   False)
        pwd_score   = self._net.get("pwd_score",   None)
        pwd_issues  = self._net.get("pwd_issues",  [])
        pwd_entropy = self._net.get("pwd_entropy", 0.0)
        pwd_masked  = self._net.get("pwd_masked",  "")

        self.setObjectName("NetworkCard")
        border_c = color if evil else B1
        self.setStyleSheet(f"""
            #NetworkCard {{
                background: {BG2};
                border: 1px solid {border_c};
                border-left: 4px solid {color};
                border-radius: 8px;
                margin-bottom: 6px;
            }}
            #NetworkCard:hover {{
                border-color: {color if evil else B2};
                background: {BG3};
            }}
        """)

        main = QVBoxLayout(self)
        main.setContentsMargins(12, 11, 14, 11)
        main.setSpacing(7)

        # ── Top row: ring | info | right score ───────────────────────────────
        top = QHBoxLayout(); top.setSpacing(12)

        ring = ScoreRing(54)
        ring.set_score_instant(score, verdict)
        top.addWidget(ring)

        info = QVBoxLayout(); info.setSpacing(4)

        # SSID + badge row
        s1 = QHBoxLayout(); s1.setSpacing(6)
        sl = QLabel(ssid); sl.setFont(sf(12, bold=True))
        sl.setStyleSheet(f"color:{T1};")
        s1.addWidget(sl)

        def badge(txt: str, c: str) -> QLabel:
            rc, gc, bc = QColor(c).red(), QColor(c).green(), QColor(c).blue()
            b = QLabel(txt); b.setFont(mf(8, bold=True))
            b.setStyleSheet(
                f"color:{c}; background:rgba({rc},{gc},{bc},0.16);"
                f"border:1px solid rgba({rc},{gc},{bc},0.35);"
                f"border-radius:4px; padding:1px 7px;")
            return b

        if self._rank == 0 and not evil: s1.addWidget(badge("★ Best",      GRN))
        if evil:                          s1.addWidget(badge("⚠ EVIL TWIN", RED))
        elif verdict == "caution":        s1.addWidget(badge("Caution",     YLW))
        elif verdict == "avoid":          s1.addWidget(badge("Avoid",       ORG))
        if isp and isp not in ("Unknown","Home","Enterprise"):
            s1.addWidget(badge(isp, ACC))
        s1.addStretch()
        info.addLayout(s1)

        # Meta line
        band = "5 GHz" if freq >= 5000 else "2.4 GHz"
        meta = QLabel(
            f"{bssid}  ·  {proto}  ·  {band} ch.{chan}  ·  "
            f"{sig} dBm  ·  PMF:{'✓' if pmf else '✗'}  ·  "
            f"WPS:{'ON' if wps else 'off'}")
        meta.setFont(mf(9)); meta.setStyleSheet(f"color:{T3};")
        info.addWidget(meta)

        # 8 vector chips
        chips = QHBoxLayout(); chips.setSpacing(4)
        for key in ["enc","eviltwin","signal","pmf","wps","band","hidden","isp"]:
            v  = vecs.get(key, {})
            st = v.get("status","na")
            vc = GRN if st == "pass" else RED if st == "fail" else YLW
            vr, vg, vb = QColor(vc).red(), QColor(vc).green(), QColor(vc).blue()
            c2 = QLabel(f"{v.get('label','?')} {v.get('pts','?')}/{v.get('max','?')}")
            c2.setFont(mf(8))
            c2.setToolTip(
                f"{v.get('label')}: {v.get('detail')}  "
                f"({v.get('pts')}/{v.get('max')} pts)")
            c2.setStyleSheet(
                f"color:{vc}; background:rgba({vr},{vg},{vb},0.08);"
                f"border:1px solid rgba({vr},{vg},{vb},0.25);"
                f"border-radius:3px; padding:1px 5px;")
            chips.addWidget(c2)
        chips.addStretch()
        info.addLayout(chips)

        top.addLayout(info); top.addStretch()

        # Right column: numeric score + verdict + progress bar
        right = QVBoxLayout()
        right.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        right.setSpacing(3)
        sc_l = QLabel(str(score)); sc_l.setFont(mf(26, bold=True))
        sc_l.setStyleSheet(f"color:{color};")
        sc_l.setAlignment(Qt.AlignmentFlag.AlignRight)
        right.addWidget(sc_l)
        vd_l = QLabel("EVIL TWIN" if evil else verdict.upper())
        vd_l.setFont(mf(8, bold=True))
        vd_l.setStyleSheet(f"color:{color};")
        vd_l.setAlignment(Qt.AlignmentFlag.AlignRight)
        right.addWidget(vd_l)
        prog = QProgressBar(); prog.setRange(0,100); prog.setValue(score)
        prog.setTextVisible(False); prog.setFixedWidth(96); prog.setFixedHeight(4)
        prog.setStyleSheet(
            f"QProgressBar{{background:{BG4};border:none;border-radius:2px;}}"
            f"QProgressBar::chunk{{background:{color};border-radius:2px;}}")
        right.addWidget(prog)
        top.addLayout(right)
        main.addLayout(top)

        # ── Password strength row (only when a saved password was found) ──────
        if pwd_found and pwd_score is not None:
            main.addWidget(self._build_pwd_row(
                pwd_score, pwd_issues, pwd_entropy, pwd_masked))

        # ── Recommendation strip ──────────────────────────────────────────────
        rec = self._net.get("rec","")
        rc  = GRN if verdict == "safe" else RED if evil else YLW
        rr, rg, rb = QColor(rc).red(), QColor(rc).green(), QColor(rc).blue()
        rl = QLabel(rec); rl.setFont(mf(9)); rl.setWordWrap(True)
        rl.setStyleSheet(
            f"color:{rc}; background:rgba({rr},{rg},{rb},0.07);"
            f"border:1px solid rgba({rr},{rg},{rb},0.22);"
            f"border-radius:5px; padding:5px 10px;")
        main.addWidget(rl)

        # ── Expandable vector breakdown (shown on click) ───────────────────
        self._exp_w = QWidget(); self._exp_w.setVisible(False)
        eg = QGridLayout(self._exp_w); eg.setSpacing(7)
        for i, key in enumerate(["enc","eviltwin","signal","pmf","wps","band","hidden","isp"]):
            v   = vecs.get(key, {})
            st  = v.get("status","na")
            vc2 = GRN if st == "pass" else RED if st == "fail" else YLW
            cell = QFrame()
            cell.setStyleSheet(f"background:{BG4}; border-radius:5px;")
            cl = QVBoxLayout(cell)
            cl.setContentsMargins(8, 6, 8, 6); cl.setSpacing(2)
            nl = QLabel(v.get("label","?")); nl.setFont(mf(7))
            nl.setStyleSheet(f"color:{T4};")
            pl = QLabel(f"{v.get('pts',0)}/{v.get('max',0)}")
            pl.setFont(mf(12, bold=True)); pl.setStyleSheet(f"color:{vc2};")
            dl = QLabel(str(v.get("detail",""))[:22])
            dl.setFont(mf(7)); dl.setStyleSheet(f"color:{T3};")
            cl.addWidget(nl); cl.addWidget(pl); cl.addWidget(dl)
            eg.addWidget(cell, i // 4, i % 4)
        main.addWidget(self._exp_w)

    # ─────────────────────────────────────────────────────────────────────────
    # Password strength row builder
    # ─────────────────────────────────────────────────────────────────────────
    def _build_pwd_row(self, score: int, issues: list,
                       entropy: float, masked: str) -> QWidget:
        """
        Inline password strength widget embedded in the card.
        Shows: 🔐 icon · strength bar · score/100 · entropy · top issue.
        """
        # Colour by score band
        if score >= 80:
            bar_c  = GRN
            status = "Strong"
        elif score >= 50:
            bar_c  = YLW
            status = "Acceptable"
        elif score > 0:
            bar_c  = RED
            status = "Weak — change this password!"
        else:
            bar_c  = T3
            status = "Open network (no password)"

        rc, gc, bc = QColor(bar_c).red(), QColor(bar_c).green(), QColor(bar_c).blue()

        container = QFrame()
        container.setStyleSheet(
            f"background:rgba({rc},{gc},{bc},0.06);"
            f"border:1px solid rgba({rc},{gc},{bc},0.22);"
            f"border-radius:6px;")
        row = QHBoxLayout(container)
        row.setContentsMargins(10, 6, 10, 6)
        row.setSpacing(8)

        # 🔐 icon + label
        icon = QLabel("🔐"); icon.setFont(QFont("Segoe UI Emoji", 11))
        row.addWidget(icon)

        # Strength bar
        bar = QProgressBar()
        bar.setRange(0, 100)
        bar.setValue(score)
        bar.setTextVisible(False)
        bar.setFixedHeight(6)
        bar.setFixedWidth(90)
        bar.setStyleSheet(
            f"QProgressBar{{background:{BG4};border:none;border-radius:3px;}}"
            f"QProgressBar::chunk{{background:{bar_c};border-radius:3px;}}")
        row.addWidget(bar)

        # Score number
        sc_lbl = QLabel(f"{score}/100")
        sc_lbl.setFont(mf(9, bold=True))
        sc_lbl.setStyleSheet(f"color:{bar_c};")
        row.addWidget(sc_lbl)

        # Entropy
        ent_lbl = QLabel(f"{entropy:.0f} bits")
        ent_lbl.setFont(mf(8))
        ent_lbl.setStyleSheet(f"color:{T3};")
        row.addWidget(ent_lbl)

        # Masked password
        if masked:
            mp = QLabel(masked)
            mp.setFont(mf(9))
            mp.setStyleSheet(f"color:{T3};")
            row.addWidget(mp)

        row.addStretch()

        # Status / top issue
        top_issue = issues[0] if issues else status
        st_lbl = QLabel(top_issue)
        st_lbl.setFont(mf(9))
        st_lbl.setStyleSheet(f"color:{bar_c};")
        st_lbl.setToolTip("\n".join(issues) if issues else "Password is strong")
        row.addWidget(st_lbl)

        return container

    # ─────────────────────────────────────────────────────────────────────────
    def mousePressEvent(self, _):
        self._expanded = not self._expanded
        self._exp_w.setVisible(self._expanded)
        self.selected.emit(self._net)
