"""
OmniFi — WiFi Mode Switch Dialog
===================================
A clean dialog shown when the user clicks Mode → Switch mode / re-login.

Shows:
  • Currently connected WiFi (read from OS) — pre-selected
  • List of all saved WiFi networks (for switching)
  • Client / Admin mode selector
  • Router credential fields (Admin only) — auto-filled from ISP detection
  • "Test Login" button that verifies credentials against the actual router
  • Live credential-test result (success/fail with detail)

result_mode : "client" | "admin"
result_url  : router URL (admin only)
result_user : username  (admin only)
result_pass : password  (admin only)
"""
from __future__ import annotations

import logging
from typing import Callable, Optional

from PyQt6.QtCore    import Qt, QThread, pyqtSignal, QTimer
from PyQt6.QtGui     import QFont
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QLineEdit, QFrame, QListWidget, QListWidgetItem,
    QProgressBar, QGroupBox, QApplication, QStackedWidget,
    QRadioButton, QButtonGroup,
)

from ui.theme import (
    BG0, BG1, BG2, BG3, BG4, B1, B2,
    T1, T2, T3, T4, ACC, GRN, YLW, RED, ORG,
    rgba, mf, sf,
)

log = logging.getLogger("OmniFi.WifiModeSwitch")


# ─────────────────────────────────────────────────────────────────────────────
class _LoginThread(QThread):
    done = pyqtSignal(dict)

    def __init__(self, fn: Callable, url: str, user: str, pwd: str):
        super().__init__()
        self._fn  = fn
        self._url = url
        self._user = user
        self._pwd  = pwd

    def run(self):
        try:
            result = self._fn(self._url, self._user, self._pwd)
            self.done.emit(result)
        except Exception as e:
            self.done.emit({"ok": False, "error": str(e)})


# ─────────────────────────────────────────────────────────────────────────────
class _WifiModeSwitchDialog(QDialog):
    """
    Combined WiFi selector + Client/Admin mode switcher.
    Use as: dlg = _WifiModeSwitchDialog(...); dlg.exec()
    """

    def __init__(self,
                 backend,
                 login_fn: Callable,
                 auto_detect_fn: Optional[Callable] = None,
                 parent=None):
        super().__init__(parent)
        self._b            = backend
        self._login_fn     = login_fn
        self._auto_detect  = auto_detect_fn
        self._login_thread: Optional[_LoginThread] = None

        # Results
        self.result_mode = "client"
        self.result_url  = ""
        self.result_user = ""
        self.result_pass = ""

        self.setWindowTitle("OmniFi — Switch Mode")
        self.setMinimumWidth(520)
        self.setModal(True)
        self.setStyleSheet(f"""
            QDialog      {{ background:{BG0}; }}
            QLabel       {{ color:{T2}; }}
            QLineEdit    {{ background:{BG2}; border:1px solid {B2};
                           border-radius:5px; color:{T1}; padding:4px 8px; }}
            QLineEdit:focus {{ border-color:{ACC}; }}
            QPushButton  {{ background:{BG3}; border:1px solid {B2};
                           border-radius:5px; color:{T2}; padding:4px 12px; }}
            QPushButton:hover {{ background:{BG4}; }}
            QGroupBox    {{ border:1px solid {B1}; border-radius:6px;
                           margin-top:8px; padding:8px; color:{T3}; }}
            QGroupBox::title {{ subcontrol-origin:margin; left:10px; color:{T3}; }}
            QListWidget  {{ background:{BG1}; border:1px solid {B1};
                           border-radius:5px; color:{T2}; }}
            QListWidget::item:selected {{ background:{rgba(ACC,0.15)};
                                         color:{ACC}; }}
            QRadioButton {{ color:{T2}; }}
            QRadioButton:checked {{ color:{ACC}; font-weight:600; }}
        """)
        self._build()
        QTimer.singleShot(100, self._auto_fill)

    # ── UI ────────────────────────────────────────────────────────────────────
    def _build(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(20, 16, 20, 16)
        root.setSpacing(12)

        # Title
        title = QLabel("Switch WiFi Mode")
        title.setFont(mf(13, bold=True))
        title.setStyleSheet(f"color:{T1};")
        root.addWidget(title)

        sub = QLabel("Select your connected network and choose how to interact with it.")
        sub.setFont(mf(9))
        sub.setStyleSheet(f"color:{T4};")
        root.addWidget(sub)

        # ── Interface selector (multi-adapter support) ────────────────────
        try:
            from core.backend import list_wireless_interfaces
            ifaces = list_wireless_interfaces()
        except Exception:
            ifaces = []
        if len(ifaces) > 1:
            iface_grp = QGroupBox("WiFi Adapter  (multiple detected)")
            il = QHBoxLayout(iface_grp); il.setSpacing(8)
            from PyQt6.QtWidgets import QComboBox
            iface_note = QLabel("Select which adapter to use:")
            iface_note.setFont(mf(9)); iface_note.setStyleSheet(f"color:{T3};")
            self._iface_combo = QComboBox()
            self._iface_combo.setFixedHeight(28)
            for ifc in ifaces:
                name = ifc.get("name","?")
                ssid = ifc.get("connected_ssid","")
                label = f"{name}  •  {ssid}" if ssid else f"{name}  (not connected)"
                self._iface_combo.addItem(label, ifc)
                if ssid:   # pre-select the one with a connection
                    self._iface_combo.setCurrentIndex(self._iface_combo.count()-1)
            self._iface_combo.currentIndexChanged.connect(self._on_iface_changed)
            il.addWidget(iface_note); il.addWidget(self._iface_combo, 1)
            root.addWidget(iface_grp)
        else:
            self._iface_combo = None
            # Store the single iface so _auto_fill can use it
            self._single_iface = ifaces[0] if ifaces else {}

        sep = QFrame(); sep.setFrameShape(QFrame.Shape.HLine)
        sep.setStyleSheet(f"color:{B1};"); root.addWidget(sep)

        # ── Connected WiFi display ─────────────────────────────────────────
        wifi_grp = QGroupBox("Connected Network")
        wl = QVBoxLayout(wifi_grp); wl.setSpacing(6)
        self._cur_lbl = QLabel("Detecting…")
        self._cur_lbl.setFont(mf(11, bold=True))
        self._cur_lbl.setStyleSheet(f"color:{GRN};")
        self._gw_lbl  = QLabel("")
        self._gw_lbl.setFont(mf(9))
        self._gw_lbl.setStyleSheet(f"color:{T4};")
        self._isp_lbl = QLabel("")
        self._isp_lbl.setFont(mf(9))
        self._isp_lbl.setStyleSheet(
            f"color:{ACC}; background:{rgba(ACC,0.08)}; border:1px solid {rgba(ACC,0.2)};"
            f"border-radius:4px; padding:2px 8px;")
        self._isp_lbl.setVisible(False)
        wl.addWidget(self._cur_lbl)
        wl.addWidget(self._gw_lbl)
        wl.addWidget(self._isp_lbl)
        root.addWidget(wifi_grp)

        # ── Mode selector ──────────────────────────────────────────────────
        mode_grp = QGroupBox("Connection Mode")
        ml = QVBoxLayout(mode_grp); ml.setSpacing(8)

        self._mode_group = QButtonGroup(self)
        self._rb_client = QRadioButton(
            "📡  Client Mode  —  monitoring and detection only, no router access")
        self._rb_admin  = QRadioButton(
            "🛡  Admin Mode   —  full router configuration and enforcement")
        self._rb_client.setChecked(True)
        self._mode_group.addButton(self._rb_client, 0)
        self._mode_group.addButton(self._rb_admin,  1)
        self._rb_client.toggled.connect(self._on_mode_changed)
        ml.addWidget(self._rb_client)
        ml.addWidget(self._rb_admin)
        root.addWidget(mode_grp)

        # ── Admin credentials (hidden in client mode) ──────────────────────
        self._admin_frame = QFrame()
        self._admin_frame.setVisible(False)
        self._admin_frame.setStyleSheet(
            f"background:{BG1}; border:1px solid {B2}; border-radius:6px;")
        af = QVBoxLayout(self._admin_frame)
        af.setContentsMargins(14, 10, 14, 10); af.setSpacing(8)

        af_title = QLabel("Router Admin Credentials")
        af_title.setFont(mf(10, bold=True))
        af_title.setStyleSheet(f"color:{T1};")
        af.addWidget(af_title)

        af_note = QLabel(
            "OmniFi verifies your credentials against the router login page.\n"
            "Your password is hashed locally — never stored in plaintext.")
        af_note.setWordWrap(True)
        af_note.setFont(mf(8))
        af_note.setStyleSheet(f"color:{T4};")
        af.addWidget(af_note)

        url_row = QHBoxLayout()
        url_row.addWidget(QLabel("Router URL:"))
        self._url = QLineEdit()
        self._url.setPlaceholderText("http://192.168.55.1")
        self._url.setFixedHeight(30)
        url_row.addWidget(self._url, 1)
        af.addLayout(url_row)

        user_row = QHBoxLayout()
        user_row.addWidget(QLabel("Username:  "))
        self._user = QLineEdit()
        self._user.setPlaceholderText("admin")
        self._user.setFixedHeight(30)
        user_row.addWidget(self._user, 1)
        af.addLayout(user_row)

        pass_row = QHBoxLayout()
        pass_row.addWidget(QLabel("Password:  "))
        self._pass = QLineEdit()
        self._pass.setEchoMode(QLineEdit.EchoMode.Password)
        self._pass.setPlaceholderText("router password")
        self._pass.setFixedHeight(30)
        self._pass.textChanged.connect(self._check_ready)
        pass_row.addWidget(self._pass, 1)
        af.addLayout(pass_row)

        # Test login row
        test_row = QHBoxLayout()
        self._test_btn = QPushButton("🔑 Verify Credentials")
        self._test_btn.setFixedHeight(30)
        self._test_btn.setStyleSheet(
            f"background:{rgba(ACC,0.1)}; border:1px solid {ACC}; color:{ACC};"
            f"border-radius:5px; padding:0 14px; font-weight:600;")
        self._test_btn.clicked.connect(self._test_login)
        self._test_btn.setEnabled(False)
        self._prog = QProgressBar()
        self._prog.setRange(0, 0)
        self._prog.setFixedHeight(4)
        self._prog.setVisible(False)
        test_row.addWidget(self._test_btn); test_row.addStretch()
        af.addLayout(test_row)
        af.addWidget(self._prog)

        self._result_lbl = QLabel("")
        self._result_lbl.setWordWrap(True)
        self._result_lbl.setFont(mf(9))
        self._result_lbl.setVisible(False)
        af.addWidget(self._result_lbl)

        root.addWidget(self._admin_frame)

        # ── Action buttons ─────────────────────────────────────────────────
        sep2 = QFrame(); sep2.setFrameShape(QFrame.Shape.HLine)
        sep2.setStyleSheet(f"color:{B1};"); root.addWidget(sep2)

        btn_row = QHBoxLayout(); btn_row.setSpacing(8)
        self._ok_btn = QPushButton("✔  Apply Mode")
        self._ok_btn.setFixedHeight(34)
        self._ok_btn.setStyleSheet(
            f"background:{rgba(GRN,0.12)}; border:1px solid {GRN}; color:{GRN};"
            f"border-radius:5px; font-weight:700; padding:0 18px;")
        self._ok_btn.clicked.connect(self._accept)
        cancel = QPushButton("Cancel")
        cancel.setFixedHeight(34)
        cancel.clicked.connect(self.reject)
        btn_row.addStretch()
        btn_row.addWidget(cancel)
        btn_row.addWidget(self._ok_btn)
        root.addLayout(btn_row)

    # ── Logic ─────────────────────────────────────────────────────────────────
    def _on_iface_changed(self, idx: int):
        """Re-fill when user selects a different adapter."""
        QTimer.singleShot(50, self._auto_fill)

    def _get_selected_iface(self) -> dict:
        """Return the currently selected iface dict."""
        if hasattr(self, "_iface_combo") and self._iface_combo:
            return self._iface_combo.currentData() or {}
        return getattr(self, "_single_iface", {})

    def _auto_fill(self):
        """Auto-detect current WiFi and router info for the selected adapter."""
        iface_info = self._get_selected_iface()
        iface_name = iface_info.get("name", "")
        try:
            from core.backend import connected_ssid, gateway_ip, detect_isp
            # Use interface-specific SSID if available
            ssid = iface_info.get("connected_ssid", "") or connected_ssid()
            gw   = gateway_ip(iface_name) if iface_name else gateway_ip()
            isp_key, isp_prof = detect_isp(gw, ssid) if gw else ("unknown", {})

            ssid_display = ssid or "Not connected"
            self._cur_lbl.setText(f"📶  {ssid_display}")
            self._cur_lbl.setStyleSheet(
                f"color:{GRN if ssid else YLW};")

            if gw:
                self._gw_lbl.setText(
                    f"Gateway: {gw}  •  Router URL: http://{gw}")
                self._url.setText(f"http://{gw}")
            else:
                self._gw_lbl.setText("Gateway not detected — enter router URL manually")

            isp_name = isp_prof.get("name", "")
            if isp_name and isp_name != "Unknown":
                self._isp_lbl.setText(f"  {isp_name}  ")
                self._isp_lbl.setVisible(True)
                creds = isp_prof.get("creds", [])
                if creds and not self._user.text():
                    self._user.setText(creds[0][0] if creds[0] else "admin")
        except Exception as e:
            self._gw_lbl.setText(f"Auto-detect error: {e}")

    def _on_mode_changed(self):
        is_admin = self._rb_admin.isChecked()
        self._admin_frame.setVisible(is_admin)
        if is_admin and not self._url.text():
            QTimer.singleShot(50, self._auto_fill)
        self.adjustSize()

    def _check_ready(self):
        has_creds = (bool(self._url.text().strip()) and
                     bool(self._pass.text()))
        self._test_btn.setEnabled(has_creds)

    def _test_login(self):
        url  = self._url.text().strip()
        user = self._user.text().strip() or "admin"
        pwd  = self._pass.text()
        if not url or not pwd:
            self._result_lbl.setText("Enter URL and password first.")
            self._result_lbl.setVisible(True)
            return

        self._test_btn.setEnabled(False)
        self._prog.setVisible(True)
        self._result_lbl.setVisible(False)

        self._login_thread = _LoginThread(self._login_fn, url, user, pwd)
        self._login_thread.done.connect(self._on_login_result)
        self._login_thread.start()

    def _on_login_result(self, result: dict):
        self._prog.setVisible(False)
        self._test_btn.setEnabled(True)
        self._result_lbl.setVisible(True)

        if result.get("ok"):
            isp = result.get("isp_name", "")
            dc  = result.get("default_creds_work", False)
            lines = ["✅  Credentials verified — Admin mode will be enabled"]
            if isp:
                lines.append(f"    ISP: {isp}")
            if dc:
                lines.append("    ⚠  Default credentials work — change them immediately!")
            self._result_lbl.setText("\n".join(lines))
            self._result_lbl.setStyleSheet(
                f"color:{GRN}; background:{rgba(GRN,0.07)}; border:1px solid {rgba(GRN,0.2)};"
                f"border-radius:4px; padding:6px;")
            # Auto-accept after 1.5 seconds
            QTimer.singleShot(1500, self._accept)
        else:
            err = result.get("error", "Login failed")
            self._result_lbl.setText(
                f"❌  Login failed: {err}\n"
                f"    Check the URL, username, and password.\n"
                f"    Tip: Try http://{self._url.text().replace('http://','').split('/')[0]}")
            self._result_lbl.setStyleSheet(
                f"color:{RED}; background:{rgba(RED,0.07)}; border:1px solid {rgba(RED,0.2)};"
                f"border-radius:4px; padding:6px;")

    def _accept(self):
        self.result_mode = "admin" if self._rb_admin.isChecked() else "client"
        if self.result_mode == "admin":
            self.result_url  = self._url.text().strip()
            self.result_user = self._user.text().strip() or "admin"
            self.result_pass = self._pass.text()
        self.accept()
